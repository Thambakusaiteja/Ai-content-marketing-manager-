"""
AI Content Marketing Optimizer - Main Application Package
"""

from app.api_integrations import google_sheets, twitter_api, youtube_api
from app.content_engine import (
    generator, optimizer,
    generate_content, optimize_content,
    analyze_readability, suggest_improvements
)
from app.metrics_hub import alerts, tracker
from app.sentiment_engine import analyzer
from app.config_manager import get_config_manager, get_config

__version__ = "1.0.0"
__author__ = "AI Content Marketing Team"

__all__ = [
    # API Integrations
    "google_sheets",
    "twitter_api",
    "youtube_api",
    # Content Engine
    "generator",
    "optimizer",
    "generate_content",
    "optimize_content",
    "analyze_readability",
    "suggest_improvements",
    # Metrics Hub
    "alerts",
    "tracker",
    # Sentiment Engine
    "analyzer",
    # Configuration
    "get_config_manager",
    "get_config",
]

