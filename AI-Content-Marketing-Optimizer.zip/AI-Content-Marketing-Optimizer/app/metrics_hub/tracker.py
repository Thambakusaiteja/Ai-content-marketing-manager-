"""
Metrics Tracking Module
Real-time performance metrics tracking and analytics
"""

import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import os
import json


class MetricsTracker:
    """Track and analyze content performance metrics"""
    
    def __init__(self, data_path: str = "data/mock_engagement.csv"):
        """Initialize metrics tracker"""
        self.data_path = data_path
        self.metrics_history = []
        self.load_data()
    
    def load_data(self) -> pd.DataFrame:
        """Load engagement data from CSV"""
        try:
            if os.path.exists(self.data_path):
                self.df = pd.read_csv(self.data_path)
                return self.df
            else:
                # Create sample data if doesn't exist
                self.df = self._create_sample_data()
                return self.df
        except Exception as e:
            print(f"Error loading data: {e}")
            self.df = self._create_sample_data()
            return self.df
    
    def _create_sample_data(self) -> pd.DataFrame:
        """Create sample engagement data"""
        data = {
            'content_id': ['1', '2', '3', '4', '5'],
            'title': ['AI Trends 2025', 'Marketing Guide', 'SEO Tips', 'Social Strategy', 'Video Tutorial'],
            'content_type': ['blog', 'blog', 'article', 'guide', 'video'],
            'views': [1500, 2000, 1200, 1800, 2500],
            'likes': [150, 250, 120, 180, 350],
            'comments': [45, 80, 30, 55, 120],
            'shares': [25, 60, 18, 40, 85],
            'date': pd.date_range(start='2025-12-01', periods=5),
        }
        return pd.DataFrame(data)
    
    def calculate_metrics(self, df: Optional[pd.DataFrame] = None) -> Dict:
        """
        Calculate comprehensive performance metrics.
        
        Args:
            df (pd.DataFrame): Data to analyze (uses loaded data if None)
            
        Returns:
            Dict: Calculated metrics
        """
        if df is None:
            df = self.df
        
        if df.empty:
            return self._empty_metrics()
        
        # Calculate engagement metrics
        total_views = df['views'].sum()
        total_likes = df['likes'].sum()
        total_comments = df['comments'].sum()
        total_shares = df['shares'].sum()
        total_engagement = total_likes + total_comments + total_shares
        
        metrics = {
            # Volume metrics
            'total_posts': len(df),
            'total_views': int(total_views),
            'total_likes': int(total_likes),
            'total_comments': int(total_comments),
            'total_shares': int(total_shares),
            
            # Average metrics
            'avg_views': round(df['views'].mean(), 2),
            'avg_likes': round(df['likes'].mean(), 2),
            'avg_comments': round(df['comments'].mean(), 2),
            'avg_shares': round(df['shares'].mean(), 2),
            
            # Engagement rates
            'overall_engagement_rate': round((total_engagement / total_views * 100), 2) if total_views > 0 else 0,
            'avg_engagement_rate': round(((df['likes'] + df['comments'] + df['shares']) / df['views'] * 100).mean(), 2),
            'like_rate': round((total_likes / total_views * 100), 2) if total_views > 0 else 0,
            'comment_rate': round((total_comments / total_views * 100), 2) if total_views > 0 else 0,
            'share_rate': round((total_shares / total_views * 100), 2) if total_views > 0 else 0,
            
            # Performance indicators
            'top_performing': self.get_top_content(df, 1),
            'lowest_performing': self.get_lowest_content(df, 1),
            'engagement_trend': self.calculate_trend(df),
            'performance_score': self.calculate_performance_score(df),
        }
        
        # Store in history
        self.metrics_history.append({
            'timestamp': datetime.now().isoformat(),
            'metrics': metrics
        })
        
        return metrics
    
    def _empty_metrics(self) -> Dict:
        """Return empty metrics structure"""
        return {
            'total_posts': 0,
            'total_views': 0,
            'total_likes': 0,
            'total_comments': 0,
            'total_shares': 0,
            'avg_views': 0,
            'avg_likes': 0,
            'avg_comments': 0,
            'avg_shares': 0,
            'overall_engagement_rate': 0,
            'avg_engagement_rate': 0,
            'performance_score': 0
        }
    
    def get_top_content(self, df: Optional[pd.DataFrame] = None, n: int = 5) -> List[Dict]:
        """Get top performing content"""
        if df is None:
            df = self.df
        
        if df.empty:
            return []
        
        # Calculate engagement score
        df_copy = df.copy()
        df_copy['engagement_score'] = (
            df_copy['likes'] + 
            df_copy['comments'] * 2 + 
            df_copy['shares'] * 3
        )
        
        top = df_copy.nlargest(n, 'engagement_score')
        
        return [
            {
                'title': row['title'],
                'type': row['content_type'],
                'views': int(row['views']),
                'engagement_score': int(row['engagement_score']),
                'engagement_rate': round((row['engagement_score'] / row['views'] * 100), 2)
            }
            for _, row in top.iterrows()
        ]
    
    def get_lowest_content(self, df: Optional[pd.DataFrame] = None, n: int = 5) -> List[Dict]:
        """Get lowest performing content"""
        if df is None:
            df = self.df
        
        if df.empty:
            return []
        
        # Calculate engagement score
        df_copy = df.copy()
        df_copy['engagement_score'] = (
            df_copy['likes'] + 
            df_copy['comments'] * 2 + 
            df_copy['shares'] * 3
        )
        
        lowest = df_copy.nsmallest(n, 'engagement_score')
        
        return [
            {
                'title': row['title'],
                'type': row['content_type'],
                'views': int(row['views']),
                'engagement_score': int(row['engagement_score']),
                'recommendation': 'Consider improving content or promotion strategy'
            }
            for _, row in lowest.iterrows()
        ]
    
    def calculate_trend(self, df: Optional[pd.DataFrame] = None) -> str:
        """Calculate engagement trend"""
        if df is None:
            df = self.df
        
        if len(df) < 2:
            return "Insufficient data"
        
        # Calculate engagement rate for first half vs second half
        mid = len(df) // 2
        first_half = df.iloc[:mid]
        second_half = df.iloc[mid:]
        
        first_avg = ((first_half['likes'] + first_half['comments'] + first_half['shares']) / first_half['views']).mean()
        second_avg = ((second_half['likes'] + second_half['comments'] + second_half['shares']) / second_half['views']).mean()
        
        change_percent = ((second_avg - first_avg) / first_avg * 100) if first_avg > 0 else 0
        
        if change_percent > 10:
            return f"📈 Upward - {change_percent:.1f}% improvement"
        elif change_percent < -10:
            return f"📉 Downward - {abs(change_percent):.1f}% decline"
        else:
            return f"➡️ Stable - {abs(change_percent):.1f}% variance"
    
    def calculate_performance_score(self, df: Optional[pd.DataFrame] = None) -> float:
        """Calculate overall performance score (0-100)"""
        if df is None:
            df = self.df
        
        if df.empty:
            return 0.0
        
        # Normalize metrics to 0-1 scale
        avg_engagement = ((df['likes'] + df['comments'] + df['shares']) / df['views']).mean()
        engagement_score = min(1.0, avg_engagement * 20)  # Assume 5% is excellent
        
        # Share quality (shares are most valuable engagement)
        share_rate = (df['shares'] / df['views']).mean()
        share_score = min(1.0, share_rate * 50)
        
        # Comment quality (comments indicate deeper engagement)
        comment_rate = (df['comments'] / df['views']).mean()
        comment_score = min(1.0, comment_rate * 100)
        
        # Combined score
        final_score = (engagement_score * 0.4 + share_score * 0.35 + comment_score * 0.25) * 100
        
        return round(final_score, 1)
    
    def get_metrics_by_content_type(self, df: Optional[pd.DataFrame] = None) -> Dict:
        """Get metrics grouped by content type"""
        if df is None:
            df = self.df
        
        if df.empty or 'content_type' not in df.columns:
            return {}
        
        grouped = df.groupby('content_type').agg({
            'views': 'mean',
            'likes': 'mean',
            'comments': 'mean',
            'shares': 'mean'
        }).round(2)
        
        return grouped.to_dict('index')
    
    def get_time_series_metrics(self, days: int = 30) -> Dict:
        """Get metrics over time"""
        if self.df.empty or 'date' not in self.df.columns:
            return {}
        
        # Convert date column to datetime if needed
        if 'date' in self.df.columns:
            df = self.df.copy()
            df['date'] = pd.to_datetime(df['date'], errors='coerce')
            
            # Group by date and calculate daily metrics
            daily = df.groupby('date').agg({
                'views': 'sum',
                'likes': 'sum',
                'comments': 'sum',
                'shares': 'sum'
            }).reset_index()
            
            return daily.to_dict('records')
        
        return {}
    
    def generate_report(self) -> str:
        """Generate formatted metrics report"""
        metrics = self.calculate_metrics()
        
        report = f"""
╔══════════════════════════════════════════════════════════════╗
║              PERFORMANCE METRICS REPORT                      ║
║                  {datetime.now().strftime('%Y-%m-%d %H:%M')}                           ║
╚══════════════════════════════════════════════════════════════╝

📊 VOLUME METRICS
├─ Total Posts: {metrics['total_posts']}
├─ Total Views: {metrics['total_views']:,}
├─ Total Likes: {metrics['total_likes']:,}
├─ Total Comments: {metrics['total_comments']:,}
└─ Total Shares: {metrics['total_shares']:,}

📈 AVERAGE METRICS
├─ Avg Views: {metrics['avg_views']:,.0f}
├─ Avg Likes: {metrics['avg_likes']:.0f}
├─ Avg Comments: {metrics['avg_comments']:.0f}
└─ Avg Shares: {metrics['avg_shares']:.0f}

🎯 ENGAGEMENT RATES
├─ Overall Engagement: {metrics['overall_engagement_rate']:.2f}%
├─ Like Rate: {metrics['like_rate']:.2f}%
├─ Comment Rate: {metrics['comment_rate']:.2f}%
└─ Share Rate: {metrics['share_rate']:.2f}%

⭐ PERFORMANCE INDICATORS
├─ Performance Score: {metrics['performance_score']}/100
├─ Trend: {metrics['engagement_trend']}
└─ Status: {"🔥 Excellent" if metrics['performance_score'] > 80 else "👍 Good" if metrics['performance_score'] > 60 else "⚠️ Needs Improvement"}

        """
        
        if metrics['top_performing']:
            report += "\n🏆 TOP PERFORMING CONTENT\n"
            for i, content in enumerate(metrics['top_performing'], 1):
                report += f"  {i}. {content['title']} - {content['engagement_score']} engagement\n"
        
        return report


# Global tracker instance
_tracker = MetricsTracker()


def load_mock_metrics() -> pd.DataFrame:
    """Load mock engagement metrics"""
    return _tracker.load_data()


def calculate_metrics(df: Optional[pd.DataFrame] = None) -> Dict:
    """Calculate performance metrics"""
    return _tracker.calculate_metrics(df)


def get_metrics_report() -> str:
    """Get formatted metrics report"""
    return _tracker.generate_report()


def get_top_content(n: int = 5) -> List[Dict]:
    """Get top performing content"""
    return _tracker.get_top_content(n=n)


def get_metrics_by_type() -> Dict:
    """Get metrics by content type"""
    return _tracker.get_metrics_by_content_type()

