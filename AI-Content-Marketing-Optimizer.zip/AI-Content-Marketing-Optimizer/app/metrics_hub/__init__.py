"""
Metrics Hub Package
Performance tracking, analytics, and alert management
"""

from app.metrics_hub.tracker import (
    load_mock_metrics,
    calculate_metrics,
    get_metrics_report,
    get_top_content,
    get_metrics_by_type,
    MetricsTracker
)

from app.metrics_hub.alerts import (
    engagement_alert,
    sentiment_alert,
    get_alert_manager,
    AlertManager
)

__all__ = [
    "load_mock_metrics",
    "calculate_metrics",
    "get_metrics_report",
    "get_top_content",
    "get_metrics_by_type",
    "MetricsTracker",
    "engagement_alert",
    "sentiment_alert",
    "get_alert_manager",
    "AlertManager"
]
