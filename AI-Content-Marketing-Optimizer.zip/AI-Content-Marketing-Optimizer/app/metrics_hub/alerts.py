"""
Alert Management Module
Real-time alerts and notifications based on metrics thresholds
"""

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Dict, List, Optional, Callable
from datetime import datetime
import os


class AlertManager:
    """
    Comprehensive alert management system with multiple notification channels
    """

    def __init__(self, email_config: Optional[Dict] = None):
        """
        Initialize alert manager.
        
        Args:
            email_config (Dict): Email configuration
                {
                    "sender": "email@gmail.com",
                    "password": "app_password",
                    "receiver": "recipient@gmail.com",
                    "smtp_server": "smtp.gmail.com",
                    "smtp_port": 587
                }
        """
        self.email_config = email_config
        self.alerts_history = []
        self.alert_rules = {}
    
    # ========================================
    # EMAIL ALERTS
    # ========================================
    
    def send_email_alert(self, subject: str, message: str) -> bool:
        """
        Send email alert.
        
        Args:
            subject (str): Email subject
            message (str): Email body
            
        Returns:
            bool: Success status
        """
        if not self.email_config:
            print("📧 Email alert skipped: Email configuration not provided.")
            return False
        
        try:
            msg = MIMEMultipart()
            msg['From'] = self.email_config['sender']
            msg['To'] = self.email_config['receiver']
            msg['Subject'] = subject
            msg.attach(MIMEText(message, 'plain'))
            
            server = smtplib.SMTP(
                self.email_config['smtp_server'],
                self.email_config['smtp_port']
            )
            server.starttls()
            server.login(
                self.email_config['sender'],
                self.email_config['password']
            )
            server.send_message(msg)
            server.quit()
            
            self._record_alert('email', subject, message, 'success')
            return True
        
        except Exception as e:
            print(f"❌ Failed to send email alert: {e}")
            self._record_alert('email', subject, message, 'failed', str(e))
            return False
    
    # ========================================
    # THRESHOLD-BASED ALERTS
    # ========================================
    
    def alert_if_below(
        self, 
        metric_name: str, 
        value: float, 
        threshold: float,
        severity: str = "warning"
    ) -> bool:
        """
        Trigger alert if value falls below threshold.
        
        Args:
            metric_name (str): Metric name
            value (float): Current value
            threshold (float): Threshold value
            severity (str): Alert severity (info, warning, critical)
            
        Returns:
            bool: Alert triggered status
        """
        if value < threshold:
            severity_icon = {"info": "ℹ️", "warning": "⚠️", "critical": "🔴"}.get(severity, "⚠️")
            subject = f"{severity_icon} Alert: {metric_name} Below Threshold"
            message = f"""
{metric_name} has dropped below the acceptable threshold.

Current Value: {value:.2f}
Threshold: {threshold:.2f}
Difference: {threshold - value:.2f}
Severity: {severity.upper()}

Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Action Recommended: Review recent content performance and adjust strategy.
            """
            self.send_email_alert(subject, message)
            return True
        return False
    
    def alert_if_above(
        self, 
        metric_name: str, 
        value: float, 
        threshold: float,
        severity: str = "info"
    ) -> bool:
        """
        Trigger alert if value exceeds threshold.
        
        Args:
            metric_name (str): Metric name
            value (float): Current value
            threshold (float): Threshold value
            severity (str): Alert severity (info, warning, critical)
            
        Returns:
            bool: Alert triggered status
        """
        if value > threshold:
            severity_icon = {"info": "ℹ️", "warning": "⚠️", "critical": "🔴"}.get(severity, "ℹ️")
            subject = f"{severity_icon} Alert: {metric_name} Above Threshold"
            message = f"""
{metric_name} has exceeded the threshold.

Current Value: {value:.2f}
Threshold: {threshold:.2f}
Excess: {value - threshold:.2f}
Severity: {severity.upper()}

Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Action Recommended: Monitor closely and consider scaling up successful strategies.
            """
            self.send_email_alert(subject, message)
            return True
        return False
    
    # ========================================
    # ENGAGEMENT ALERTS
    # ========================================
    
    def check_engagement_alerts(self, metrics: Dict) -> List[str]:
        """
        Check engagement metrics against thresholds.
        
        Args:
            metrics (Dict): Metrics dictionary
            
        Returns:
            List[str]: List of triggered alerts
        """
        alerts = []
        
        # Low engagement alert
        if metrics.get('overall_engagement_rate', 0) < 3.0:
            alert_msg = f"⚠️ Low Engagement: {metrics['overall_engagement_rate']:.2f}% (threshold: 3%)"
            alerts.append(alert_msg)
            self.send_email_alert(
                "Low Engagement Alert",
                f"Engagement rate is below target.\n\nCurrent: {metrics['overall_engagement_rate']:.2f}%"
            )
        
        # High engagement alert
        if metrics.get('overall_engagement_rate', 0) > 10.0:
            alert_msg = f"🎉 High Engagement: {metrics['overall_engagement_rate']:.2f}% (excellent!)"
            alerts.append(alert_msg)
        
        # Performance score alert
        if metrics.get('performance_score', 0) < 50:
            alert_msg = f"📉 Low Performance Score: {metrics['performance_score']}/100"
            alerts.append(alert_msg)
        
        return alerts
    
    def check_sentiment_alerts(self, sentiment_score: float) -> List[str]:
        """
        Check sentiment metrics against thresholds.
        
        Args:
            sentiment_score (float): Sentiment score (-1 to 1)
            
        Returns:
            List[str]: List of triggered alerts
        """
        alerts = []
        
        if sentiment_score < -0.5:
            alert_msg = f"⚠️ Negative Sentiment Detected: {sentiment_score:.2f}"
            alerts.append(alert_msg)
            self.send_email_alert(
                "Negative Sentiment Alert",
                f"Content sentiment is significantly negative: {sentiment_score:.2f}"
            )
        
        if sentiment_score > 0.75:
            alert_msg = f"✨ Excellent Sentiment: {sentiment_score:.2f}"
            alerts.append(alert_msg)
        
        return alerts
    
    # ========================================
    # ANOMALY DETECTION
    # ========================================
    
    def detect_anomalies(self, current_metrics: Dict, previous_metrics: Dict) -> List[str]:
        """
        Detect anomalies by comparing current vs previous metrics.
        
        Args:
            current_metrics (Dict): Current metrics
            previous_metrics (Dict): Previous metrics
            
        Returns:
            List[str]: List of detected anomalies
        """
        anomalies = []
        
        # Check for significant drops
        for metric in ['overall_engagement_rate', 'avg_views', 'performance_score']:
            if metric in current_metrics and metric in previous_metrics:
                current = current_metrics.get(metric, 0)
                previous = previous_metrics.get(metric, 0)
                
                if previous > 0:
                    change_percent = ((current - previous) / previous) * 100
                    
                    if change_percent < -20:
                        anomaly = f"📉 {metric}: {abs(change_percent):.1f}% drop detected"
                        anomalies.append(anomaly)
                    elif change_percent > 20:
                        anomaly = f"📈 {metric}: {change_percent:.1f}% increase detected"
                        anomalies.append(anomaly)
        
        return anomalies
    
    # ========================================
    # ALERT RULES
    # ========================================
    
    def add_rule(
        self, 
        rule_name: str, 
        condition: Callable, 
        action: Callable
    ) -> None:
        """
        Add custom alert rule.
        
        Args:
            rule_name (str): Rule name
            condition (Callable): Function that returns True/False
            action (Callable): Function to execute when condition is met
        """
        self.alert_rules[rule_name] = {
            'condition': condition,
            'action': action
        }
    
    def check_custom_rules(self, metrics: Dict) -> List[str]:
        """
        Check all custom alert rules.
        
        Args:
            metrics (Dict): Metrics to check against rules
            
        Returns:
            List[str]: Triggered alerts
        """
        triggered_alerts = []
        
        for rule_name, rule in self.alert_rules.items():
            try:
                if rule['condition'](metrics):
                    result = rule['action'](metrics)
                    triggered_alerts.append(f"Rule '{rule_name}': {result}")
            except Exception as e:
                print(f"Error executing rule '{rule_name}': {e}")
        
        return triggered_alerts
    
    # ========================================
    # ALERT REPORTING
    # ========================================
    
    def _record_alert(
        self, 
        alert_type: str, 
        subject: str, 
        message: str, 
        status: str,
        error: Optional[str] = None
    ) -> None:
        """Record alert in history"""
        self.alerts_history.append({
            'timestamp': datetime.now().isoformat(),
            'type': alert_type,
            'subject': subject,
            'message': message,
            'status': status,
            'error': error
        })
    
    def get_alert_history(self, limit: int = 10) -> List[Dict]:
        """Get recent alert history"""
        return self.alerts_history[-limit:]
    
    def generate_alert_report(self) -> str:
        """Generate formatted alert report"""
        report = f"""
╔══════════════════════════════════════════════════════════════╗
║              ALERT MANAGEMENT REPORT                        ║
║                  {datetime.now().strftime('%Y-%m-%d %H:%M')}                           ║
╚══════════════════════════════════════════════════════════════╝

📋 ALERT CONFIGURATION
├─ Email Alerts: {"✓ Enabled" if self.email_config else "✗ Disabled"}
├─ Custom Rules: {len(self.alert_rules)}
└─ Alert History: {len(self.alerts_history)} events

📊 RECENT ALERTS
        """
        
        if self.alerts_history:
            for alert in self.alerts_history[-5:]:
                report += f"\n  • [{alert['status'].upper()}] {alert['subject']}"
                report += f"\n    Time: {alert['timestamp']}"
        else:
            report += "\n  No alerts recorded yet"
        
        return report


# Global alert manager instance
_alert_manager = AlertManager()


def engagement_alert(metrics: Dict) -> str:
    """Check engagement and return alert message"""
    alerts = _alert_manager.check_engagement_alerts(metrics)
    
    if not alerts:
        return "✅ All engagement metrics within normal range"
    
    return "\n".join(alerts)


def sentiment_alert(sentiment_score: float) -> str:
    """Check sentiment and return alert message"""
    alerts = _alert_manager.check_sentiment_alerts(sentiment_score)
    
    if not alerts:
        return "✅ Sentiment metrics normal"
    
    return "\n".join(alerts)


def get_alert_manager() -> AlertManager:
    """Get global alert manager instance"""
    return _alert_manager

