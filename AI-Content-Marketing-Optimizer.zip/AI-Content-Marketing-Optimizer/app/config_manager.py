"""
Configuration Management Module
Loads and manages application settings from YAML configuration file
"""

import os
import yaml
from typing import Dict, Any, Optional
import logging

logger = logging.getLogger(__name__)


class ConfigManager:
    """Manages application configuration from YAML file"""
    
    def __init__(self, config_path: str = None):
        """
        Initialize configuration manager.
        
        Args:
            config_path (str): Path to settings.yaml file
        """
        if config_path is None:
            config_path = os.path.join(
                os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                'config',
                'settings.yaml'
            )
        
        self.config_path = config_path
        self.config = self._load_config()
    
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from YAML file"""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            logger.info(f"Configuration loaded from {self.config_path}")
            return config or {}
        except FileNotFoundError:
            logger.warning(f"Configuration file not found: {self.config_path}")
            return {}
        except yaml.YAMLError as e:
            logger.error(f"Error parsing YAML configuration: {e}")
            return {}
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        Get configuration value by dot-notation key.
        
        Example: get("content_engine.defaults.tone")
        
        Args:
            key (str): Configuration key with dot notation
            default (Any): Default value if key not found
            
        Returns:
            Any: Configuration value
        """
        keys = key.split('.')
        value = self.config
        
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
                if value is None:
                    return default
            else:
                return default
        
        return value if value is not None else default
    
    def get_section(self, section: str) -> Dict[str, Any]:
        """
        Get entire configuration section.
        
        Args:
            section (str): Section name
            
        Returns:
            Dict: Section configuration
        """
        return self.config.get(section, {})
    
    def get_api_config(self, api_name: str) -> Dict[str, Any]:
        """
        Get API-specific configuration.
        
        Args:
            api_name (str): API name (twitter, youtube, google_sheets)
            
        Returns:
            Dict: API configuration with environment variables resolved
        """
        api_section = self.get(f"api_integrations.{api_name}", {})
        
        # Replace environment variables
        resolved_config = {}
        for key, value in api_section.items():
            if isinstance(value, str) and value.startswith("${") and value.endswith("}"):
                env_var = value[2:-1]
                resolved_config[key] = os.getenv(env_var, value)
            else:
                resolved_config[key] = value
        
        return resolved_config
    
    def get_content_type_config(self, content_type: str) -> Dict[str, Any]:
        """
        Get content type configuration.
        
        Args:
            content_type (str): Content type name
            
        Returns:
            Dict: Content type configuration
        """
        return self.get(f"content_engine.content_types.{content_type}", {})
    
    def get_tone_config(self, tone: str) -> Dict[str, Any]:
        """
        Get tone configuration.
        
        Args:
            tone (str): Tone name
            
        Returns:
            Dict: Tone configuration
        """
        return self.get(f"content_engine.tones.{tone}", {})
    
    def get_audience_config(self, audience: str) -> Dict[str, Any]:
        """
        Get audience configuration.
        
        Args:
            audience (str): Audience name
            
        Returns:
            Dict: Audience configuration
        """
        return self.get(f"content_engine.audiences.{audience}", {})
    
    def get_alert_threshold(self, alert_type: str) -> float:
        """
        Get alert threshold value.
        
        Args:
            alert_type (str): Alert type
            
        Returns:
            float: Threshold value
        """
        return self.get(f"metrics.alerts.{alert_type}", 0.0)
    
    def is_feature_enabled(self, feature_name: str) -> bool:
        """
        Check if a feature is enabled.
        
        Args:
            feature_name (str): Feature name with dot notation
            
        Returns:
            bool: Feature enabled status
        """
        return self.get(f"features.{feature_name}", False)
    
    def get_database_config(self) -> Dict[str, Any]:
        """
        Get database configuration with resolved environment variables.
        
        Returns:
            Dict: Database configuration
        """
        db_config = self.get_section("database")
        db_type = db_config.get("type", "sqlite")
        
        if db_type == "sqlite":
            return db_config.get("sqlite", {})
        elif db_type == "postgresql":
            config = db_config.get("postgresql", {})
        elif db_type == "mysql":
            config = db_config.get("mysql", {})
        else:
            return {}
        
        # Resolve environment variables
        resolved = {}
        for key, value in config.items():
            if isinstance(value, str) and value.startswith("${") and value.endswith("}"):
                env_var = value[2:-1]
                resolved[key] = os.getenv(env_var, value)
            else:
                resolved[key] = value
        
        return resolved
    
    def reload(self) -> None:
        """Reload configuration from file"""
        self.config = self._load_config()
        logger.info("Configuration reloaded")
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Get entire configuration as dictionary.
        
        Returns:
            Dict: Complete configuration
        """
        return self.config.copy()


# Global configuration instance
_config_manager = None


def get_config_manager() -> ConfigManager:
    """
    Get or create global configuration manager instance.
    
    Returns:
        ConfigManager: Configuration manager instance
    """
    global _config_manager
    if _config_manager is None:
        _config_manager = ConfigManager()
    return _config_manager


def get_config(key: str, default: Any = None) -> Any:
    """
    Quick access to configuration values.
    
    Args:
        key (str): Configuration key
        default (Any): Default value
        
    Returns:
        Any: Configuration value
    """
    return get_config_manager().get(key, default)


def load_config(config_path: str) -> ConfigManager:
    """
    Load configuration from file.
    
    Args:
        config_path (str): Path to configuration file
        
    Returns:
        ConfigManager: Configuration manager instance
    """
    global _config_manager
    _config_manager = ConfigManager(config_path)
    return _config_manager


# Example usage functions
def get_app_config() -> Dict[str, Any]:
    """Get app configuration section"""
    return get_config_manager().get_section("app")


def get_content_engine_config() -> Dict[str, Any]:
    """Get content engine configuration section"""
    return get_config_manager().get_section("content_engine")


def get_sentiment_config() -> Dict[str, Any]:
    """Get sentiment analysis configuration section"""
    return get_config_manager().get_section("sentiment")


def get_optimizer_config() -> Dict[str, Any]:
    """Get optimizer configuration section"""
    return get_config_manager().get_section("optimizer")


def get_metrics_config() -> Dict[str, Any]:
    """Get metrics configuration section"""
    return get_config_manager().get_section("metrics")
