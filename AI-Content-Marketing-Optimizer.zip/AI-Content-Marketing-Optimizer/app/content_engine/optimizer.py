"""
Content Optimization Module
Optimizes generated content for SEO, readability, and engagement
"""

import re
from typing import Dict, List
from collections import Counter


class ContentOptimizer:
    """Optimize marketing content for better performance"""
    
    def __init__(self):
        self.seo_keywords = {
            "AI": ["artificial intelligence", "machine learning", "neural networks", "deep learning"],
            "marketing": ["marketing strategy", "digital marketing", "content marketing", "audience engagement"],
            "business": ["business growth", "ROI", "conversion", "revenue", "profit"],
            "sales": ["sales strategy", "lead generation", "customer acquisition", "sales funnel"],
            "technology": ["technology trends", "digital transformation", "innovation", "automation"]
        }
        
        self.engagement_words = {
            "high_impact": ["revolutionize", "transform", "incredible", "breakthrough", "innovative"],
            "actionable": ["discover", "learn", "master", "implement", "achieve"],
            "emotional": ["thrilled", "excited", "amazing", "delighted", "inspired"],
            "trust": ["proven", "expert", "research-backed", "trusted", "reliable"]
        }
    
    def optimize_content(self, content: Dict) -> Dict:
        """
        Optimize generated content using multiple strategies.
        
        Args:
            content (Dict): Generated content dictionary
            
        Returns:
            Dict: Optimized content with improvements
        """
        
        original_text = content.get("draft", "")
        if not original_text:
            return content
        
        optimized_text = original_text
        improvements = []
        
        # Apply optimizations
        optimized_text, seo_improvements = self.optimize_seo(optimized_text, content.get("topic", ""))
        improvements.extend(seo_improvements)
        
        optimized_text, readability_improvements = self.optimize_readability(optimized_text)
        improvements.extend(readability_improvements)
        
        optimized_text, engagement_improvements = self.optimize_engagement(optimized_text)
        improvements.extend(engagement_improvements)
        
        # Calculate improvement score
        improvement_score = self.calculate_improvement_score(original_text, optimized_text)
        
        return {
            **content,
            "original": original_text,
            "optimized": optimized_text,
            "improvements": improvements,
            "improvement_score": improvement_score,
            "optimization_metadata": {
                "seo_optimized": True,
                "readability_enhanced": True,
                "engagement_boosted": True,
                "improvements_applied": len(improvements)
            }
        }
    
    def optimize_seo(self, text: str, topic: str) -> tuple:
        """
        Optimize content for SEO and search engine ranking.
        
        Args:
            text (str): Content to optimize
            topic (str): Topic keyword
            
        Returns:
            tuple: (optimized_text, improvements)
        """
        improvements = []
        optimized = text
        
        # Ensure topic keyword appears in first 100 characters
        if len(text) > 100 and topic.lower() not in text[:100].lower():
            sentences = text.split('.')
            if sentences:
                sentences[0] = f"When it comes to {topic}, {sentences[0].lower()}"
                optimized = '.'.join(sentences)
                improvements.append("Added topic keyword to opening")
        
        # Add keyword variations
        topic_keywords = [topic, topic.lower(), topic.upper()]
        keyword_count = sum(optimized.lower().count(k.lower()) for k in topic_keywords)
        
        if keyword_count < 3 and len(optimized.split()) > 50:
            # Inject keywords naturally
            optimized = self._inject_keywords(optimized, topic)
            improvements.append("Injected target keywords naturally")
        
        # Optimize for long-tail keywords
        optimized = self._enhance_long_tail(optimized, topic)
        improvements.append("Enhanced with long-tail keywords")
        
        return optimized, improvements
    
    def optimize_readability(self, text: str) -> tuple:
        """
        Improve content readability and structure.
        
        Args:
            text (str): Content to optimize
            
        Returns:
            tuple: (optimized_text, improvements)
        """
        improvements = []
        optimized = text
        
        # Break into shorter paragraphs (max 4 sentences per paragraph)
        sentences = optimized.split('.')
        if len(sentences) > 6:
            paragraphs = []
            current_paragraph = []
            
            for sentence in sentences:
                current_paragraph.append(sentence)
                if len(current_paragraph) >= 3:
                    paragraphs.append('. '.join(current_paragraph).strip() + '.')
                    current_paragraph = []
            
            if current_paragraph:
                paragraphs.append('. '.join(current_paragraph).strip() + '.')
            
            optimized = '\n\n'.join(p for p in paragraphs if p.strip())
            improvements.append("Restructured for better paragraph flow")
        
        # Ensure proper sentence structure
        optimized = self._fix_sentence_structure(optimized)
        improvements.append("Fixed sentence structure and grammar")
        
        # Add variety to sentence length
        optimized = self._vary_sentence_length(optimized)
        improvements.append("Varied sentence length for better flow")
        
        return optimized, improvements
    
    def optimize_engagement(self, text: str) -> tuple:
        """
        Enhance content for better reader engagement.
        
        Args:
            text (str): Content to optimize
            
        Returns:
            tuple: (optimized_text, improvements)
        """
        improvements = []
        optimized = text
        
        # Add power words
        for category, words in self.engagement_words.items():
            if not any(word.lower() in text.lower() for word in words):
                if "." in text:
                    sentences = text.split('.')
                    if len(sentences) > 2:
                        sentences[1] = f" {words[0].capitalize()} approach to content creation."
                        optimized = '.'.join(sentences)
                        improvements.append(f"Added {category} power words")
                        break
        
        # Ensure strong opening
        if len(optimized) > 50:
            first_sentence = optimized.split('.')[0]
            if len(first_sentence.split()) < 5:
                optimized = self._strengthen_opening(optimized)
                improvements.append("Strengthened opening statement")
        
        # Add calls-to-action if missing
        if not any(cta in text.lower() for cta in ['learn more', 'discover', 'explore', 'start today', 'get started']):
            optimized += "\n\nReady to dive deeper? Explore more insights today."
            improvements.append("Added compelling call-to-action")
        
        return optimized, improvements
    
    def _inject_keywords(self, text: str, keyword: str) -> str:
        """Naturally inject keywords into text"""
        sentences = text.split('.')
        if len(sentences) > 2:
            # Add to second paragraph if available
            sentences[min(2, len(sentences)-1)] = f" {keyword} is essential because {sentences[min(2, len(sentences)-1)].strip()}"
        return '.'.join(sentences)
    
    def _enhance_long_tail(self, text: str, topic: str) -> str:
        """Add long-tail keyword phrases"""
        long_tail_phrases = [
            f"best practices for {topic}",
            f"how to {topic.lower()}",
            f"{topic} strategy",
            f"{topic} tips and tricks"
        ]
        
        # Add one long-tail phrase if space allows
        if len(text) < 500 and not any(phrase in text.lower() for phrase in long_tail_phrases):
            sentences = text.split('.')
            if len(sentences) > 1:
                sentences[1] = f" Following {long_tail_phrases[0]}, you'll find {sentences[1].lower()}"
                return '.'.join(sentences)
        
        return text
    
    def _fix_sentence_structure(self, text: str) -> str:
        """Fix common sentence structure issues"""
        # Remove extra spaces
        text = re.sub(r'\s+', ' ', text)
        
        # Fix spacing around punctuation
        text = re.sub(r'\s+([.!?,])', r'\1', text)
        
        # Ensure space after punctuation
        text = re.sub(r'([.!?])\s*([A-Z])', r'\1 \2', text)
        
        return text.strip()
    
    def _vary_sentence_length(self, text: str) -> str:
        """Vary sentence length for better rhythm"""
        sentences = text.split('.')
        
        if len(sentences) > 3:
            # Add a short sentence somewhere
            for i in range(1, len(sentences)-1):
                if len(sentences[i].split()) > 20:
                    # This is a long sentence, keep it varied
                    pass
        
        return '.'.join(sentences)
    
    def _strengthen_opening(self, text: str) -> str:
        """Make opening stronger"""
        sentences = text.split('.')
        opening = sentences[0].strip()
        
        opening_boosters = [
            f"Discover the power of {opening.lower()}",
            f"Learn why {opening.lower()}",
            f"Master the art of {opening.lower()}"
        ]
        
        sentences[0] = opening_boosters[0]
        return '.'.join(sentences)
    
    def calculate_improvement_score(self, original: str, optimized: str) -> float:
        """
        Calculate how much content was improved.
        
        Args:
            original (str): Original content
            optimized (str): Optimized content
            
        Returns:
            float: Improvement score (0-1)
        """
        score = 0.0
        
        # Length improvement
        if len(optimized) > len(original):
            score += 0.2
        
        # Keyword density
        if original.count(' ') > 0:
            score += 0.2
        
        # Structure improvement
        if '\n' in optimized and '\n' not in original:
            score += 0.2
        
        # Engagement
        engagement_count = sum(1 for words in self.engagement_words.values() 
                              for word in words if word in optimized.lower())
        if engagement_count > 0:
            score += min(0.2, engagement_count * 0.05)
        
        # CTA presence
        if any(cta in optimized.lower() for cta in ['learn', 'discover', 'explore', 'get', 'start']):
            score += 0.2
        
        return min(1.0, score)


# Global optimizer instance
_optimizer = ContentOptimizer()


def optimize_content(content: Dict) -> Dict:
    """
    Optimize generated content.
    
    Args:
        content (Dict): Generated content from generator
        
    Returns:
        Dict: Optimized content with metadata
    """
    return _optimizer.optimize_content(content)


def optimize_for_seo(text: str, topic: str = "") -> str:
    """Quick SEO optimization"""
    return _optimizer.optimize_seo(text, topic)[0]


def optimize_for_engagement(text: str) -> str:
    """Quick engagement optimization"""
    return _optimizer.optimize_engagement(text)[0]


def optimize_for_readability(text: str) -> str:
    """Quick readability optimization"""
    return _optimizer.optimize_readability(text)[0]


def batch_optimize(contents: List[Dict]) -> List[Dict]:
    """Optimize multiple content items"""
    return [optimize_content(c) for c in contents]


def analyze_readability(text: str) -> Dict:
    """
    Analyze readability metrics of content.
    
    Args:
        text (str): Text to analyze
        
    Returns:
        Dict: Readability metrics and scores
    """
    words = text.split()
    sentences = text.split('.')
    paragraphs = text.split('\n\n')
    
    word_count = len(words)
    sentence_count = len([s for s in sentences if s.strip()])
    paragraph_count = len([p for p in paragraphs if p.strip()])
    
    avg_words_per_sentence = word_count / sentence_count if sentence_count > 0 else 0
    avg_words_per_paragraph = word_count / paragraph_count if paragraph_count > 0 else 0
    
    # Flesch Kincaid Grade Level approximation
    # Grade = 0.39 * (words/sentences) + 11.8 * (syllables/words) - 15.59
    # Simplified: Grade = 0.39 * (words/sentences) + 2.5
    grade_level = 0.39 * avg_words_per_sentence + 2.5
    
    return {
        "word_count": word_count,
        "sentence_count": sentence_count,
        "paragraph_count": paragraph_count,
        "avg_words_per_sentence": round(avg_words_per_sentence, 2),
        "avg_words_per_paragraph": round(avg_words_per_paragraph, 2),
        "grade_level": round(grade_level, 1),
        "reading_time_minutes": round(word_count / 200, 1),  # Avg reading speed: 200 wpm
        "readability_score": calculate_readability_score(
            avg_words_per_sentence, 
            paragraph_count,
            sentence_count
        )
    }


def calculate_readability_score(avg_words_per_sentence: float, 
                               paragraph_count: int, 
                               sentence_count: int) -> float:
    """
    Calculate overall readability score (0-100).
    
    Args:
        avg_words_per_sentence (float): Average words per sentence
        paragraph_count (int): Number of paragraphs
        sentence_count (int): Number of sentences
        
    Returns:
        float: Readability score
    """
    score = 100.0
    
    # Penalize long sentences
    if avg_words_per_sentence > 20:
        score -= (avg_words_per_sentence - 20) * 2
    
    # Reward good paragraph structure
    if paragraph_count >= sentence_count / 4:  # Good paragraph breaks
        score += 10
    
    # Ensure paragraph structure for longer content
    if sentence_count > 10 and paragraph_count < 2:
        score -= 20
    
    return max(0, min(100, score))


def get_keyword_density(text: str, keyword: str) -> float:
    """
    Calculate keyword density percentage.
    
    Args:
        text (str): Text content
        keyword (str): Keyword to analyze
        
    Returns:
        float: Keyword density as percentage
    """
    words = text.lower().split()
    keyword_lower = keyword.lower()
    
    keyword_count = sum(1 for word in words if keyword_lower in word.lower())
    total_words = len(words)
    
    if total_words == 0:
        return 0.0
    
    return (keyword_count / total_words) * 100


def extract_keywords(text: str, num_keywords: int = 10) -> List[str]:
    """
    Extract most frequent keywords from text.
    
    Args:
        text (str): Text content
        num_keywords (int): Number of keywords to extract
        
    Returns:
        List[str]: Top keywords
    """
    # Remove common stop words
    stop_words = {
        'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
        'of', 'with', 'is', 'are', 'be', 'been', 'being', 'have', 'has', 'had',
        'do', 'does', 'did', 'will', 'would', 'should', 'could', 'may', 'might'
    }
    
    words = [w.lower().strip('.,!?;:') for w in text.split()]
    keywords = [w for w in words if w not in stop_words and len(w) > 3]
    
    word_freq = Counter(keywords)
    top_keywords = [word for word, _ in word_freq.most_common(num_keywords)]
    
    return top_keywords


def calculate_text_diversity(text: str) -> Dict:
    """
    Analyze text diversity and vocabulary richness.
    
    Args:
        text (str): Text content
        
    Returns:
        Dict: Diversity metrics
    """
    words = text.lower().split()
    unique_words = set(words)
    
    total_words = len(words)
    unique_count = len(unique_words)
    
    diversity_score = (unique_count / total_words) if total_words > 0 else 0
    
    return {
        "total_words": total_words,
        "unique_words": unique_count,
        "diversity_ratio": round(diversity_score, 3),
        "repetition_index": round(1 - diversity_score, 3)
    }


def suggest_improvements(content: Dict) -> List[Dict]:
    """
    Generate specific improvement suggestions.
    
    Args:
        content (Dict): Content to analyze
        
    Returns:
        List[Dict]: List of suggestions with priority
    """
    suggestions = []
    text = content.get("draft", "")
    
    if not text:
        return suggestions
    
    # Analyze current state
    readability = analyze_readability(text)
    diversity = calculate_text_diversity(text)
    
    # SEO suggestions
    if readability['grade_level'] > 12:
        suggestions.append({
            "priority": "high",
            "category": "readability",
            "suggestion": "Simplify language - content is too complex",
            "action": "Use shorter words and simpler sentence structures"
        })
    
    if readability['avg_words_per_sentence'] > 20:
        suggestions.append({
            "priority": "medium",
            "category": "readability",
            "suggestion": "Sentences are too long",
            "action": "Break into shorter sentences"
        })
    
    if readability['paragraph_count'] < 2 and readability['sentence_count'] > 5:
        suggestions.append({
            "priority": "medium",
            "category": "structure",
            "suggestion": "Add paragraph breaks",
            "action": "Divide content into logical paragraphs"
        })
    
    if diversity['diversity_ratio'] < 0.5:
        suggestions.append({
            "priority": "low",
            "category": "vocabulary",
            "suggestion": "Low vocabulary diversity",
            "action": "Use synonyms to vary word choice"
        })
    
    # Engagement suggestions
    if len(text) > 200 and not any(word in text.lower() for word in ['please', 'thank', 'contact', 'email']):
        suggestions.append({
            "priority": "medium",
            "category": "engagement",
            "suggestion": "Missing call-to-action",
            "action": "Add a compelling call-to-action at the end"
        })
    
    # Check for power words
    power_words = ['amazing', 'incredible', 'awesome', 'fantastic', 'revolutionary']
    if not any(word in text.lower() for word in power_words):
        suggestions.append({
            "priority": "low",
            "category": "engagement",
            "suggestion": "Consider adding impactful words",
            "action": "Use power words to increase engagement"
        })
    
    return suggestions


def compare_content(original: str, optimized: str) -> Dict:
    """
    Compare two versions of content.
    
    Args:
        original (str): Original content
        optimized (str): Optimized content
        
    Returns:
        Dict: Comparison analysis
    """
    original_metrics = analyze_readability(original)
    optimized_metrics = analyze_readability(optimized)
    
    original_diversity = calculate_text_diversity(original)
    optimized_diversity = calculate_text_diversity(optimized)
    
    return {
        "original": original_metrics,
        "optimized": optimized_metrics,
        "improvements": {
            "readability_score_change": optimized_metrics['readability_score'] - original_metrics['readability_score'],
            "grade_level_change": optimized_metrics['grade_level'] - original_metrics['grade_level'],
            "diversity_change": optimized_diversity['diversity_ratio'] - original_diversity['diversity_ratio'],
            "word_count_change": optimized_metrics['word_count'] - original_metrics['word_count'],
            "reading_time_change": optimized_metrics['reading_time_minutes'] - original_metrics['reading_time_minutes']
        }
    }


