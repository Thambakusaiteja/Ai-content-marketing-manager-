"""
Content Engine Package
AI-powered content generation and optimization
"""

from app.content_engine.generator import (
    generate_content,
    generate_content_ideas,
    batch_generate_content,
    calculate_quality_score
)

from app.content_engine.optimizer import (
    optimize_content,
    optimize_for_seo,
    optimize_for_engagement,
    optimize_for_readability,
    batch_optimize,
    analyze_readability,
    calculate_readability_score,
    get_keyword_density,
    extract_keywords,
    calculate_text_diversity,
    suggest_improvements,
    compare_content
)

__all__ = [
    "generate_content",
    "generate_content_ideas",
    "batch_generate_content",
    "calculate_quality_score",
    "optimize_content",
    "optimize_for_seo",
    "optimize_for_engagement",
    "optimize_for_readability",
    "batch_optimize",
    "analyze_readability",
    "calculate_readability_score",
    "get_keyword_density",
    "extract_keywords",
    "calculate_text_diversity",
    "suggest_improvements",
    "compare_content"
]


