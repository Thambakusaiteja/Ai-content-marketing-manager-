"""
Content Generation Module
Real AI-powered content generation using Hugging Face Transformers
Supports multiple content types and customizable parameters
"""

from transformers import GPT2Tokenizer, GPT2LMHeadModel, pipeline
import torch
from typing import Dict, List, Optional
import re

# Initialize the text generation pipeline
try:
    generator = pipeline('text-generation', model='gpt2', device=0 if torch.cuda.is_available() else -1)
except Exception as e:
    print(f"Note: GPU not available, using CPU. {e}")
    generator = pipeline('text-generation', model='gpt2', device=-1)

# Content templates for prompting the model
CONTENT_TEMPLATES = {
    "blog_post": """Write a professional blog post about {topic} for {audience}. 
Make it engaging, informative, and include practical tips. 
Tone: {tone}
Word count: approximately {length} words.

Title: """,
    
    "social_media": """Write a captivating social media post about {topic} for {audience}.
Make it punchy, engaging, and share-worthy.
Tone: {tone}
Length: {length} characters maximum.

Post: """,
    
    "email_newsletter": """Write an engaging email newsletter about {topic} for {audience}.
Include a subject line and compelling body text.
Tone: {tone}
Approximate length: {length} words.

Subject: """,
    
    "video_script": """Write a compelling video script about {topic} for {audience}.
Include engaging opening, key points, and call-to-action.
Tone: {tone}
Approximate length: {length} words.

Script: """,
    
    "social_caption": """Write an Instagram/Twitter caption about {topic}.
Make it catchy with relevant hashtags.
Tone: {tone}
Length: {length} characters.

Caption: """,
    
    "product_description": """Write a compelling product description for {topic}.
Target audience: {audience}
Tone: {tone}
Approximate length: {length} words.

Description: """
}

# Tone modifiers for more targeted prompts
TONE_MODIFIERS = {
    "Professional": "professional, formal, and authoritative",
    "Casual": "casual, friendly, and conversational",
    "Humorous": "witty, humorous, and entertaining",
    "Inspirational": "inspiring, motivational, and uplifting",
    "Educational": "informative, educational, and clear"
}

# Keywords by audience for better targeting
AUDIENCE_KEYWORDS = {
    "General": "everyone, general audience",
    "Tech Professionals": "developers, engineers, tech enthusiasts",
    "Marketing Managers": "marketers, business growth, engagement",
    "Business Owners": "entrepreneurs, business growth, ROI",
    "Startups": "startups, innovation, growth hacking",
    "Students": "students, learning, education",
    "Parents": "families, children, household"
}


def generate_content(
    topic: str,
    content_type: str = "blog_post",
    audience: str = "General",
    tone: str = "Professional",
    length: int = 300,
    num_variations: int = 1,
    max_new_tokens: int = None
) -> Dict:
    """
    Generates AI-powered marketing content using GPT-2.
    
    Args:
        topic (str): Topic or subject for content generation
        content_type (str): Type of content (blog_post, social_media, email_newsletter, etc.)
        audience (str): Target audience for content
        tone (str): Tone of content (Professional, Casual, Humorous, Inspirational, Educational)
        length (int): Desired length (words for blog, chars for social)
        num_variations (int): Number of content variations to generate
        max_new_tokens (int): Maximum tokens to generate
        
    Returns:
        dict: Generated content with metadata
    """
    
    if content_type not in CONTENT_TEMPLATES:
        content_type = "blog_post"
    
    if tone not in TONE_MODIFIERS:
        tone = "Professional"
    
    if audience not in AUDIENCE_KEYWORDS:
        audience = "General"
    
    # Create the prompt
    prompt = CONTENT_TEMPLATES[content_type].format(
        topic=topic,
        audience=audience,
        tone=TONE_MODIFIERS[tone],
        length=length
    )
    
    # Set token limit based on content type and length
    if max_new_tokens is None:
        if content_type == "social_media":
            max_new_tokens = min(100, length // 4)
        elif content_type == "social_caption":
            max_new_tokens = min(80, length // 4)
        else:
            max_new_tokens = min(512, (length // 4) + 50)
    
    variations = []
    
    try:
        for i in range(num_variations):
            # Generate content
            generated = generator(
                prompt,
                max_length=len(prompt.split()) + max_new_tokens,
                num_return_sequences=1,
                temperature=0.7,
                top_p=0.9,
                do_sample=True,
                pad_token_id=50256
            )
            
            # Extract the generated text
            generated_text = generated[0]['generated_text']
            
            # Clean up the output
            content = clean_generated_text(generated_text, prompt, content_type)
            
            variations.append({
                "content": content,
                "tokens_used": len(content.split()),
                "quality_score": calculate_quality_score(content, content_type)
            })
    
    except Exception as e:
        # Fallback to template-based generation if model fails
        return generate_content_fallback(topic, content_type, audience, tone, length)
    
    return {
        "topic": topic,
        "content_type": content_type,
        "audience": audience,
        "tone": tone,
        "target_length": length,
        "draft": variations[0]["content"],
        "variations": variations,
        "metadata": {
            "model": "gpt2",
            "num_variations": len(variations),
            "generation_method": "transformer"
        }
    }


def generate_content_fallback(
    topic: str,
    content_type: str = "blog_post",
    audience: str = "General",
    tone: str = "Professional",
    length: int = 300
) -> Dict:
    """
    Fallback content generation using enhanced templates.
    Used when transformer model is unavailable.
    """
    
    tone_starters = {
        "Professional": [
            f"Discover the essential insights about {topic}.",
            f"Understanding {topic} is crucial for modern business.",
            f"A comprehensive overview of {topic} and its impact."
        ],
        "Casual": [
            f"Let's talk about {topic} - it's more interesting than you think!",
            f"So, here's the thing about {topic}...",
            f"Breaking down {topic} in a way that makes sense."
        ],
        "Humorous": [
            f"Why everyone should care about {topic} (spoiler: it's hilarious)",
            f"The {topic} guide nobody asked for but everyone needs",
            f"Buckle up for this wild ride through {topic}"
        ],
        "Inspirational": [
            f"How {topic} can transform your future",
            f"The incredible potential of {topic}",
            f"Why {topic} is the key to your success"
        ],
        "Educational": [
            f"Everything you need to know about {topic}",
            f"A deep dive into {topic}: The complete guide",
            f"Master the art of {topic} with this comprehensive guide"
        ]
    }
    
    middle_content = {
        "Professional": f"Research shows that {topic} plays a vital role in modern marketing strategies. Industry experts recommend focusing on key aspects such as audience engagement, content quality, and performance metrics. By implementing best practices, organizations can achieve measurable improvements.",
        "Casual": f"Here's what makes {topic} so cool: it actually works! People are seeing real results, and it's not just hype. Whether you're new to this or already familiar, there's always something new to learn about {topic}.",
        "Humorous": f"If you're not paying attention to {topic}, you're basically missing out on the party. Seriously though, {topic} is changing the game in ways we never expected.",
        "Inspirational": f"The potential of {topic} is limitless. When you unlock its true power, you'll see transformation in every area. Join thousands who are already leveraging {topic} for remarkable growth.",
        "Educational": f"The fundamentals of {topic} are straightforward: focus on these core principles. First, understand your foundation. Second, apply proven techniques. Third, measure and optimize continuously for best results."
    }
    
    cta = {
        "Professional": "Contact us today to learn more about optimizing your {topic} strategy.",
        "Casual": "Ready to level up with {topic}? Let's do this!",
        "Humorous": "Don't be left behind - explore {topic} now!",
        "Inspirational": "Your journey with {topic} starts now. Embrace the opportunity.",
        "Educational": "Start mastering {topic} today with our comprehensive resources."
    }
    
    starter = tone_starters[tone][0]
    middle = middle_content[tone]
    call_to_action = cta[tone].format(topic=topic)
    
    content = f"{starter}\n\n{middle}\n\n{call_to_action}"
    
    return {
        "topic": topic,
        "content_type": content_type,
        "audience": audience,
        "tone": tone,
        "target_length": length,
        "draft": content,
        "variations": [{"content": content, "quality_score": 0.75}],
        "metadata": {
            "model": "template-based",
            "generation_method": "fallback"
        }
    }


def clean_generated_text(text: str, prompt: str, content_type: str) -> str:
    """
    Clean up and format generated text.
    
    Args:
        text (str): Raw generated text
        prompt (str): Original prompt used
        content_type (str): Type of content generated
        
    Returns:
        str: Cleaned text
    """
    # Remove the prompt from the output
    if prompt in text:
        text = text.replace(prompt, "").strip()
    
    # Remove redundant text
    text = re.sub(r'\n\n\n+', '\n\n', text)
    text = text.strip()
    
    # Clean up incomplete sentences
    if text.endswith(',') or text.endswith(' and'):
        sentences = text.split('.')
        text = '.'.join(sentences[:-1]) + '.'
    
    return text


def calculate_quality_score(content: str, content_type: str) -> float:
    """
    Calculate a quality score for generated content.
    
    Args:
        content (str): Generated content
        content_type (str): Type of content
        
    Returns:
        float: Quality score (0-1)
    """
    score = 0.0
    
    # Length check
    word_count = len(content.split())
    if content_type in ["social_media", "social_caption"]:
        if 5 <= word_count <= 50:
            score += 0.3
    else:
        if 50 <= word_count <= 1000:
            score += 0.3
    
    # Readability check
    has_capital = any(c.isupper() for c in content[:10])
    has_punctuation = any(p in content for p in ['.', '!', '?'])
    if has_capital and has_punctuation:
        score += 0.25
    
    # Coherence check
    sentences = content.split('.')
    if len(sentences) >= 2:
        score += 0.25
    
    # Grammar hints
    common_patterns = ['is ', 'the ', 'and ', 'for ', 'to ']
    pattern_count = sum(content.lower().count(p) for p in common_patterns)
    if pattern_count > 0:
        score += 0.2
    
    return min(1.0, score)


def generate_content_ideas(topic: str, num_ideas: int = 5) -> List[Dict]:
    """
    Generate multiple content ideas for a topic.
    
    Args:
        topic (str): Topic to generate ideas for
        num_ideas (int): Number of ideas to generate
        
    Returns:
        List[Dict]: List of content ideas
    """
    content_types = ["blog_post", "social_media", "video_script", "email_newsletter"]
    ideas = []
    
    for i in range(num_ideas):
        content_type = content_types[i % len(content_types)]
        result = generate_content(
            topic=topic,
            content_type=content_type,
            length=200
        )
        ideas.append({
            "type": content_type,
            "preview": result["draft"][:100] + "...",
            "full_content": result["draft"]
        })
    
    return ideas


def batch_generate_content(
    topics: List[str],
    content_type: str = "blog_post",
    audience: str = "General",
    tone: str = "Professional"
) -> List[Dict]:
    """
    Generate content for multiple topics.
    
    Args:
        topics (List[str]): List of topics
        content_type (str): Type of content
        audience (str): Target audience
        tone (str): Tone of content
        
    Returns:
        List[Dict]: List of generated content
    """
    results = []
    for topic in topics:
        result = generate_content(
            topic=topic,
            content_type=content_type,
            audience=audience,
            tone=tone
        )
        results.append(result)
    
    return results

