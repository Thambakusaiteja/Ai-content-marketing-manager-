"""
YouTube API Integration Module
Handles YouTube API v3 interactions for video analytics, comments, and channel management
"""

import os
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from googleapiclient.discovery import build
from dotenv import load_dotenv

# Load environment variables
load_dotenv()


class YouTubeAPIClient:
    """YouTube API v3 Client for video and channel operations"""
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize YouTube API client.
        
        Args:
            api_key (str): YouTube API key
        """
        self.api_key = api_key or os.getenv('YOUTUBE_API_KEY')
        self.youtube = None
        self.connected = self._authenticate()
    
    def _authenticate(self) -> bool:
        """
        Authenticate with YouTube API.
        
        Returns:
            bool: True if authentication successful
        """
        try:
            if not self.api_key:
                return False
            
            self.youtube = build('youtube', 'v3', developerKey=self.api_key)
            return True
        except Exception as e:
            print(f"YouTube API authentication failed: {e}")
            return False
    
    def search_videos(self, query: str, max_results: int = 50) -> Dict:
        """
        Search for videos on YouTube.
        
        Args:
            query (str): Search query
            max_results (int): Maximum results (max 50)
            
        Returns:
            Dict: Search results
        """
        try:
            if not self.youtube:
                return {"success": False, "error": "YouTube client not initialized"}
            
            request = self.youtube.search().list(
                q=query,
                part='snippet',
                maxResults=min(max_results, 50),
                type='video',
                order='relevance'
            )
            
            response = request.execute()
            
            videos = []
            for item in response.get('items', []):
                video = {
                    'video_id': item['id']['videoId'],
                    'title': item['snippet']['title'],
                    'description': item['snippet']['description'],
                    'channel_title': item['snippet']['channelTitle'],
                    'published_at': item['snippet']['publishedAt'],
                    'thumbnail': item['snippet']['thumbnails']['default']['url']
                }
                videos.append(video)
            
            return {
                "success": True,
                "query": query,
                "count": len(videos),
                "videos": videos,
                "retrieved_at": datetime.now().isoformat()
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def get_video_statistics(self, video_id: str) -> Dict:
        """
        Get statistics for a specific video.
        
        Args:
            video_id (str): YouTube video ID
            
        Returns:
            Dict: Video statistics
        """
        try:
            if not self.youtube:
                return {"success": False, "error": "YouTube client not initialized"}
            
            request = self.youtube.videos().list(
                part='statistics,snippet,contentDetails',
                id=video_id
            )
            
            response = request.execute()
            
            if not response.get('items'):
                return {"success": False, "error": "Video not found"}
            
            video = response['items'][0]
            stats = video['statistics']
            snippet = video['snippet']
            details = video['contentDetails']
            
            return {
                "success": True,
                "video_id": video_id,
                "title": snippet['title'],
                "channel": snippet['channelTitle'],
                "views": int(stats.get('viewCount', 0)),
                "likes": int(stats.get('likeCount', 0)),
                "comments": int(stats.get('commentCount', 0)),
                "duration": details.get('duration'),
                "published_at": snippet['publishedAt'],
                "retrieved_at": datetime.now().isoformat()
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def get_channel_statistics(self, channel_id: str) -> Dict:
        """
        Get statistics for a YouTube channel.
        
        Args:
            channel_id (str): YouTube channel ID
            
        Returns:
            Dict: Channel statistics
        """
        try:
            if not self.youtube:
                return {"success": False, "error": "YouTube client not initialized"}
            
            request = self.youtube.channels().list(
                part='statistics,snippet,contentDetails',
                id=channel_id
            )
            
            response = request.execute()
            
            if not response.get('items'):
                return {"success": False, "error": "Channel not found"}
            
            channel = response['items'][0]
            stats = channel['statistics']
            snippet = channel['snippet']
            
            return {
                "success": True,
                "channel_id": channel_id,
                "title": snippet['title'],
                "description": snippet['description'],
                "subscribers": int(stats.get('subscriberCount', 0)) if stats.get('hiddenSubscriberCount') == False else "Hidden",
                "total_views": int(stats.get('viewCount', 0)),
                "video_count": int(stats.get('videoCount', 0)),
                "thumbnail": snippet['thumbnails']['default']['url'],
                "retrieved_at": datetime.now().isoformat()
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def get_trending_videos(self, region_code: str = 'US', max_results: int = 50) -> Dict:
        """
        Get trending videos in a region.
        
        Args:
            region_code (str): Region code (e.g., 'US', 'GB', 'IN')
            max_results (int): Maximum results
            
        Returns:
            Dict: Trending videos
        """
        try:
            if not self.youtube:
                return {"success": False, "error": "YouTube client not initialized"}
            
            request = self.youtube.videos().list(
                part='snippet,statistics',
                chart='mostPopular',
                regionCode=region_code,
                maxResults=min(max_results, 50)
            )
            
            response = request.execute()
            
            videos = []
            for item in response.get('items', []):
                video = {
                    'video_id': item['id'],
                    'title': item['snippet']['title'],
                    'channel': item['snippet']['channelTitle'],
                    'views': int(item['statistics'].get('viewCount', 0)),
                    'likes': int(item['statistics'].get('likeCount', 0)),
                    'comments': int(item['statistics'].get('commentCount', 0))
                }
                videos.append(video)
            
            return {
                "success": True,
                "region": region_code,
                "count": len(videos),
                "videos": videos,
                "retrieved_at": datetime.now().isoformat()
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def get_video_comments(self, video_id: str, max_results: int = 100) -> Dict:
        """
        Get top comments for a video.
        
        Args:
            video_id (str): YouTube video ID
            max_results (int): Maximum comments
            
        Returns:
            Dict: Video comments
        """
        try:
            if not self.youtube:
                return {"success": False, "error": "YouTube client not initialized"}
            
            request = self.youtube.commentThreads().list(
                part='snippet',
                videoId=video_id,
                textFormat='plainText',
                maxResults=min(max_results, 100),
                order='relevance'
            )
            
            response = request.execute()
            
            comments = []
            for item in response.get('items', []):
                comment_data = item['snippet']['topLevelComment']['snippet']
                comments.append({
                    'author': comment_data['authorDisplayName'],
                    'text': comment_data['textDisplay'],
                    'likes': comment_data['likeCount'],
                    'published_at': comment_data['publishedAt']
                })
            
            return {
                "success": True,
                "video_id": video_id,
                "comment_count": len(comments),
                "comments": comments,
                "retrieved_at": datetime.now().isoformat()
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def analyze_video_performance(self, video_id: str) -> Dict:
        """
        Analyze video performance metrics.
        
        Args:
            video_id (str): YouTube video ID
            
        Returns:
            Dict: Performance analysis
        """
        try:
            stats = self.get_video_statistics(video_id)
            if not stats.get('success'):
                return stats
            
            # Calculate engagement metrics
            total_interactions = stats['likes'] + stats['comments']
            engagement_rate = (total_interactions / stats['views'] * 100) if stats['views'] > 0 else 0
            like_rate = (stats['likes'] / stats['views'] * 100) if stats['views'] > 0 else 0
            
            return {
                "success": True,
                "video_id": video_id,
                "title": stats['title'],
                "views": stats['views'],
                "engagement_rate": round(engagement_rate, 2),
                "like_rate": round(like_rate, 2),
                "total_interactions": total_interactions,
                "analysis": {
                    "engagement_level": "High" if engagement_rate > 5 else "Medium" if engagement_rate > 2 else "Low",
                    "recommendation": "Content is performing well" if engagement_rate > 5 else "Consider optimizing content"
                }
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }


# Global YouTube client instance
_youtube_client = None


def init_youtube_api(api_key: Optional[str] = None) -> Dict:
    """
    Initialize YouTube API client.
    
    Args:
        api_key (str): Optional API key (uses env if not provided)
        
    Returns:
        Dict: Initialization status
    """
    global _youtube_client
    
    try:
        _youtube_client = YouTubeAPIClient(api_key)
        
        if _youtube_client.connected:
            return {
                "service": "YouTube API v3",
                "status": "Connected",
                "message": "Successfully initialized YouTube API client"
            }
        else:
            return {
                "service": "YouTube API v3",
                "status": "Disconnected",
                "message": "API key not found. Set YOUTUBE_API_KEY environment variable."
            }
    except Exception as e:
        return {
            "service": "YouTube API v3",
            "status": "Error",
            "error": str(e)
        }


def search_videos(query: str, max_results: int = 50) -> Dict:
    """Search YouTube videos"""
    if not _youtube_client:
        init_youtube_api()
    return _youtube_client.search_videos(query, max_results) if _youtube_client else {"error": "YouTube client not initialized"}


def get_video_statistics(video_id: str) -> Dict:
    """Get video statistics"""
    if not _youtube_client:
        init_youtube_api()
    return _youtube_client.get_video_statistics(video_id) if _youtube_client else {"error": "YouTube client not initialized"}


def get_channel_statistics(channel_id: str) -> Dict:
    """Get channel statistics"""
    if not _youtube_client:
        init_youtube_api()
    return _youtube_client.get_channel_statistics(channel_id) if _youtube_client else {"error": "YouTube client not initialized"}


def get_trending_videos(region_code: str = 'US', max_results: int = 50) -> Dict:
    """Get trending videos"""
    if not _youtube_client:
        init_youtube_api()
    return _youtube_client.get_trending_videos(region_code, max_results) if _youtube_client else {"error": "YouTube client not initialized"}


def get_video_comments(video_id: str, max_results: int = 100) -> Dict:
    """Get video comments"""
    if not _youtube_client:
        init_youtube_api()
    return _youtube_client.get_video_comments(video_id, max_results) if _youtube_client else {"error": "YouTube client not initialized"}


def analyze_video_performance(video_id: str) -> Dict:
    """Analyze video performance"""
    if not _youtube_client:
        init_youtube_api()
    return _youtube_client.analyze_video_performance(video_id) if _youtube_client else {"error": "YouTube client not initialized"}


def get_client() -> Optional[YouTubeAPIClient]:
    """Get the global YouTube client instance"""
    if not _youtube_client:
        init_youtube_api()
    return _youtube_client
