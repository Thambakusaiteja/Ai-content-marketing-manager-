"""
Twitter API Integration Module
Handles Twitter/X API v2 interactions for posting, retrieving metrics, and managing content
"""

import os
import json
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import requests
from dotenv import load_dotenv

# Load environment variables
load_dotenv()


class TwitterAPIClient:
    """Twitter API v2 Client for content operations"""
    
    def __init__(self, bearer_token: Optional[str] = None):
        """
        Initialize Twitter API client.
        
        Args:
            bearer_token (str): Twitter API bearer token
        """
        self.bearer_token = bearer_token or os.getenv('TWITTER_BEARER_TOKEN')
        self.api_key = os.getenv('TWITTER_API_KEY')
        self.api_secret = os.getenv('TWITTER_API_SECRET')
        self.access_token = os.getenv('TWITTER_ACCESS_TOKEN')
        self.access_token_secret = os.getenv('TWITTER_ACCESS_TOKEN_SECRET')
        
        self.base_url = "https://api.twitter.com/2"
        self.api_v1_url = "https://api.twitter.com/1.1"
        self.headers = self._get_headers()
        self.connected = self._verify_connection()
    
    def _get_headers(self) -> Dict:
        """Get request headers with authentication"""
        return {
            "Authorization": f"Bearer {self.bearer_token}",
            "Content-Type": "application/json",
            "User-Agent": "AIContentMarketingOptimizer/1.0"
        }
    
    def _verify_connection(self) -> bool:
        """Verify Twitter API connection"""
        try:
            if not self.bearer_token:
                return False
            
            response = requests.get(
                f"{self.base_url}/tweets/search/recent?query=test&max_results=10",
                headers=self.headers,
                timeout=5
            )
            return response.status_code in [200, 429]  # 429 = rate limited but connected
        except Exception as e:
            print(f"Connection verification failed: {e}")
            return False
    
    def post_tweet(self, text: str, media_ids: Optional[List[str]] = None) -> Dict:
        """
        Post a tweet.
        
        Args:
            text (str): Tweet text (max 280 characters)
            media_ids (List[str]): Optional media IDs
            
        Returns:
            Dict: Tweet creation response
        """
        if len(text) > 280:
            return {
                "success": False,
                "error": f"Tweet text exceeds 280 characters ({len(text)})"
            }
        
        payload = {"text": text}
        if media_ids:
            payload["media"] = {"media_ids": media_ids}
        
        try:
            response = requests.post(
                f"{self.base_url}/tweets",
                json=payload,
                headers=self.headers,
                timeout=10
            )
            
            if response.status_code == 201:
                data = response.json()
                return {
                    "success": True,
                    "tweet_id": data['data']['id'],
                    "text": text,
                    "created_at": datetime.now().isoformat()
                }
            else:
                return {
                    "success": False,
                    "error": response.json().get('detail', 'Unknown error'),
                    "status_code": response.status_code
                }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def get_user_metrics(self, user_id: Optional[str] = None) -> Dict:
        """
        Get user metrics and follower count.
        
        Args:
            user_id (str): User ID (uses authenticated user if not provided)
            
        Returns:
            Dict: User metrics
        """
        try:
            # Get authenticated user
            if not user_id:
                response = requests.get(
                    f"{self.base_url}/users/me",
                    headers=self.headers,
                    timeout=10
                )
                if response.status_code != 200:
                    return {"success": False, "error": "Could not get authenticated user"}
                user_id = response.json()['data']['id']
            
            # Get user data with public metrics
            response = requests.get(
                f"{self.base_url}/users/{user_id}?user.fields=public_metrics",
                headers=self.headers,
                timeout=10
            )
            
            if response.status_code == 200:
                user_data = response.json()['data']
                metrics = user_data.get('public_metrics', {})
                
                return {
                    "success": True,
                    "user_id": user_id,
                    "followers": metrics.get('followers_count', 0),
                    "following": metrics.get('following_count', 0),
                    "tweets": metrics.get('tweet_count', 0),
                    "likes_received": metrics.get('like_count', 0),
                    "retrieved_at": datetime.now().isoformat()
                }
            else:
                return {
                    "success": False,
                    "error": f"Status code: {response.status_code}"
                }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def get_tweet_metrics(self, tweet_id: str) -> Dict:
        """
        Get metrics for a specific tweet.
        
        Args:
            tweet_id (str): Tweet ID
            
        Returns:
            Dict: Tweet metrics (likes, retweets, replies, quotes)
        """
        try:
            response = requests.get(
                f"{self.base_url}/tweets/{tweet_id}?tweet.fields=public_metrics,created_at",
                headers=self.headers,
                timeout=10
            )
            
            if response.status_code == 200:
                tweet = response.json()['data']
                metrics = tweet.get('public_metrics', {})
                
                return {
                    "success": True,
                    "tweet_id": tweet_id,
                    "likes": metrics.get('like_count', 0),
                    "retweets": metrics.get('retweet_count', 0),
                    "replies": metrics.get('reply_count', 0),
                    "quotes": metrics.get('quote_count', 0),
                    "created_at": tweet.get('created_at'),
                    "retrieved_at": datetime.now().isoformat()
                }
            else:
                return {
                    "success": False,
                    "error": f"Status code: {response.status_code}"
                }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def search_tweets(self, query: str, max_results: int = 100) -> Dict:
        """
        Search recent tweets.
        
        Args:
            query (str): Search query
            max_results (int): Maximum results to return
            
        Returns:
            Dict: Search results
        """
        try:
            response = requests.get(
                f"{self.base_url}/tweets/search/recent",
                headers=self.headers,
                params={
                    "query": query,
                    "max_results": min(max_results, 100),
                    "tweet.fields": "created_at,public_metrics"
                },
                timeout=10
            )
            
            if response.status_code == 200:
                tweets = response.json().get('data', [])
                return {
                    "success": True,
                    "query": query,
                    "count": len(tweets),
                    "tweets": tweets,
                    "retrieved_at": datetime.now().isoformat()
                }
            else:
                return {
                    "success": False,
                    "error": f"Status code: {response.status_code}"
                }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def delete_tweet(self, tweet_id: str) -> Dict:
        """
        Delete a tweet.
        
        Args:
            tweet_id (str): Tweet ID to delete
            
        Returns:
            Dict: Deletion response
        """
        try:
            response = requests.delete(
                f"{self.base_url}/tweets/{tweet_id}",
                headers=self.headers,
                timeout=10
            )
            
            if response.status_code == 200:
                return {
                    "success": True,
                    "deleted_at": datetime.now().isoformat()
                }
            else:
                return {
                    "success": False,
                    "error": f"Status code: {response.status_code}"
                }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def get_timeline(self, max_results: int = 100) -> Dict:
        """
        Get authenticated user's timeline.
        
        Args:
            max_results (int): Maximum tweets to return
            
        Returns:
            Dict: Timeline tweets
        """
        try:
            # Get authenticated user ID first
            response = requests.get(
                f"{self.base_url}/users/me",
                headers=self.headers,
                timeout=10
            )
            if response.status_code != 200:
                return {"success": False, "error": "Could not get authenticated user"}
            
            user_id = response.json()['data']['id']
            
            # Get timeline
            response = requests.get(
                f"{self.base_url}/users/{user_id}/tweets",
                headers=self.headers,
                params={
                    "max_results": min(max_results, 100),
                    "tweet.fields": "created_at,public_metrics"
                },
                timeout=10
            )
            
            if response.status_code == 200:
                tweets = response.json().get('data', [])
                return {
                    "success": True,
                    "count": len(tweets),
                    "tweets": tweets,
                    "retrieved_at": datetime.now().isoformat()
                }
            else:
                return {
                    "success": False,
                    "error": f"Status code: {response.status_code}"
                }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }


# Global Twitter client instance
_twitter_client = None


def init_twitter_api(bearer_token: Optional[str] = None) -> Dict:
    """
    Initialize Twitter API client.
    
    Args:
        bearer_token (str): Optional bearer token (uses env if not provided)
        
    Returns:
        Dict: Initialization status
    """
    global _twitter_client
    
    try:
        _twitter_client = TwitterAPIClient(bearer_token)
        
        if _twitter_client.connected:
            return {
                "service": "Twitter API v2",
                "status": "Connected",
                "message": "Successfully initialized Twitter API client"
            }
        else:
            return {
                "service": "Twitter API v2",
                "status": "Disconnected",
                "message": "Bearer token not found. Set TWITTER_BEARER_TOKEN environment variable."
            }
    except Exception as e:
        return {
            "service": "Twitter API v2",
            "status": "Error",
            "error": str(e)
        }


def post_tweet(text: str, media_ids: Optional[List[str]] = None) -> Dict:
    """Post a tweet using the global client"""
    if not _twitter_client:
        init_twitter_api()
    return _twitter_client.post_tweet(text, media_ids) if _twitter_client else {"error": "Twitter client not initialized"}


def get_user_metrics() -> Dict:
    """Get authenticated user metrics"""
    if not _twitter_client:
        init_twitter_api()
    return _twitter_client.get_user_metrics() if _twitter_client else {"error": "Twitter client not initialized"}


def get_tweet_metrics(tweet_id: str) -> Dict:
    """Get tweet metrics"""
    if not _twitter_client:
        init_twitter_api()
    return _twitter_client.get_tweet_metrics(tweet_id) if _twitter_client else {"error": "Twitter client not initialized"}


def search_tweets(query: str, max_results: int = 100) -> Dict:
    """Search tweets"""
    if not _twitter_client:
        init_twitter_api()
    return _twitter_client.search_tweets(query, max_results) if _twitter_client else {"error": "Twitter client not initialized"}


def get_client() -> Optional[TwitterAPIClient]:
    """Get the global Twitter client instance"""
    if not _twitter_client:
        init_twitter_api()
    return _twitter_client