"""
Google Sheets API Integration Module
Handles Google Sheets interactions for content management, metrics tracking, and data synchronization
"""

import os
import json
from typing import Dict, List, Optional, Any
from datetime import datetime
import gspread
from google.oauth2.service_account import Credentials
from dotenv import load_dotenv

# Load environment variables
load_dotenv()


class GoogleSheetsClient:
    """Google Sheets API Client for content and metrics management"""
    
    def __init__(self, credentials_file: Optional[str] = None, sheet_id: Optional[str] = None):
        """
        Initialize Google Sheets client.
        
        Args:
            credentials_file (str): Path to service account credentials JSON
            sheet_id (str): Google Sheet ID
        """
        self.credentials_file = credentials_file or os.getenv('GOOGLE_CREDENTIALS_FILE')
        self.sheet_id = sheet_id or os.getenv('GOOGLE_SHEET_ID')
        self.client = None
        self.sheet = None
        self.connected = self._authenticate()
    
    def _authenticate(self) -> bool:
        """
        Authenticate with Google Sheets API.
        
        Returns:
            bool: True if authentication successful
        """
        try:
            if not self.credentials_file or not os.path.exists(self.credentials_file):
                return False
            
            # Set up credentials
            scopes = [
                'https://www.googleapis.com/auth/spreadsheets',
                'https://www.googleapis.com/auth/drive'
            ]
            
            credentials = Credentials.from_service_account_file(
                self.credentials_file,
                scopes=scopes
            )
            
            self.client = gspread.authorize(credentials)
            
            if self.sheet_id:
                self.sheet = self.client.open_by_key(self.sheet_id)
            
            return True
        except Exception as e:
            print(f"Google Sheets authentication failed: {e}")
            return False
    
    def create_sheet(self, title: str) -> Dict:
        """
        Create a new spreadsheet.
        
        Args:
            title (str): Name for new spreadsheet
            
        Returns:
            Dict: Creation result
        """
        try:
            sheet = self.client.create(title)
            return {
                "success": True,
                "sheet_id": sheet.id,
                "sheet_url": sheet.url,
                "title": title
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def append_row(self, worksheet_name: str, values: List[Any]) -> Dict:
        """
        Append a row to worksheet.
        
        Args:
            worksheet_name (str): Worksheet name
            values (List): Row values
            
        Returns:
            Dict: Append result
        """
        try:
            if not self.sheet:
                return {"success": False, "error": "Sheet not initialized"}
            
            worksheet = self.sheet.worksheet(worksheet_name)
            worksheet.append_row(values)
            
            return {
                "success": True,
                "appended_at": datetime.now().isoformat(),
                "row_count": len(worksheet.get_all_values())
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def append_content(self, topic: str, content: str, content_type: str, 
                      tone: str, quality_score: float) -> Dict:
        """
        Append generated content to Content Log worksheet.
        
        Args:
            topic (str): Content topic
            content (str): Generated content
            content_type (str): Type of content
            tone (str): Tone used
            quality_score (float): Quality score
            
        Returns:
            Dict: Result
        """
        try:
            values = [
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                topic,
                content[:100],  # First 100 chars
                content_type,
                tone,
                f"{quality_score:.2f}",
                "pending"  # Status
            ]
            
            return self.append_row("Content Log", values)
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def append_metrics(self, date: str, platform: str, engagement_rate: float,
                      reach: int, impressions: int, sentiment_score: float) -> Dict:
        """
        Append metrics to Metrics worksheet.
        
        Args:
            date (str): Date of metrics
            platform (str): Social media platform
            engagement_rate (float): Engagement percentage
            reach (int): Reach count
            impressions (int): Impression count
            sentiment_score (float): Average sentiment
            
        Returns:
            Dict: Result
        """
        try:
            values = [
                date,
                platform,
                f"{engagement_rate:.2f}%",
                reach,
                impressions,
                f"{sentiment_score:.2f}"
            ]
            
            return self.append_row("Metrics", values)
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def get_worksheet_data(self, worksheet_name: str) -> Dict:
        """
        Get all data from a worksheet.
        
        Args:
            worksheet_name (str): Worksheet name
            
        Returns:
            Dict: Worksheet data
        """
        try:
            if not self.sheet:
                return {"success": False, "error": "Sheet not initialized"}
            
            worksheet = self.sheet.worksheet(worksheet_name)
            data = worksheet.get_all_values()
            
            return {
                "success": True,
                "worksheet": worksheet_name,
                "rows": len(data),
                "data": data
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def update_cell(self, worksheet_name: str, row: int, col: int, value: Any) -> Dict:
        """
        Update a single cell.
        
        Args:
            worksheet_name (str): Worksheet name
            row (int): Row number (1-indexed)
            col (int): Column number (1-indexed)
            value (Any): New value
            
        Returns:
            Dict: Result
        """
        try:
            if not self.sheet:
                return {"success": False, "error": "Sheet not initialized"}
            
            worksheet = self.sheet.worksheet(worksheet_name)
            worksheet.update_cell(row, col, value)
            
            return {
                "success": True,
                "updated_at": datetime.now().isoformat()
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def update_content_status(self, row: int, status: str) -> Dict:
        """
        Update content status in Content Log.
        
        Args:
            row (int): Row number
            status (str): New status (pending, published, scheduled)
            
        Returns:
            Dict: Result
        """
        return self.update_cell("Content Log", row, 7, status)
    
    def clear_worksheet(self, worksheet_name: str) -> Dict:
        """
        Clear all data from a worksheet.
        
        Args:
            worksheet_name (str): Worksheet name
            
        Returns:
            Dict: Result
        """
        try:
            if not self.sheet:
                return {"success": False, "error": "Sheet not initialized"}
            
            worksheet = self.sheet.worksheet(worksheet_name)
            worksheet.clear()
            
            return {
                "success": True,
                "cleared_at": datetime.now().isoformat()
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def create_default_worksheets(self) -> Dict:
        """
        Create default worksheets for content and metrics.
        
        Returns:
            Dict: Creation result
        """
        try:
            if not self.sheet:
                return {"success": False, "error": "Sheet not initialized"}
            
            worksheets_created = []
            
            # Content Log worksheet
            try:
                self.sheet.add_worksheet("Content Log", rows=1000, cols=10)
                headers = ["Timestamp", "Topic", "Content Preview", "Type", "Tone", "Quality Score", "Status", "URL", "Notes", ""]
                self.sheet.worksheet("Content Log").append_row(headers)
                worksheets_created.append("Content Log")
            except:
                pass
            
            # Metrics worksheet
            try:
                self.sheet.add_worksheet("Metrics", rows=1000, cols=6)
                headers = ["Date", "Platform", "Engagement Rate", "Reach", "Impressions", "Sentiment Score"]
                self.sheet.worksheet("Metrics").append_row(headers)
                worksheets_created.append("Metrics")
            except:
                pass
            
            # Settings worksheet
            try:
                self.sheet.add_worksheet("Settings", rows=50, cols=2)
                self.sheet.worksheet("Settings").append_row(["Setting", "Value"])
                worksheets_created.append("Settings")
            except:
                pass
            
            return {
                "success": True,
                "worksheets_created": worksheets_created
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }


# Global Google Sheets client instance
_google_sheets_client = None


def connect_google_sheet(credentials_file: Optional[str] = None, 
                        sheet_id: Optional[str] = None) -> Dict:
    """
    Connect to Google Sheets.
    
    Args:
        credentials_file (str): Path to credentials JSON
        sheet_id (str): Google Sheet ID
        
    Returns:
        Dict: Connection status
    """
    global _google_sheets_client
    
    try:
        _google_sheets_client = GoogleSheetsClient(credentials_file, sheet_id)
        
        if _google_sheets_client.connected:
            return {
                "service": "Google Sheets API",
                "status": "Connected",
                "message": "Successfully initialized Google Sheets client"
            }
        else:
            return {
                "service": "Google Sheets API",
                "status": "Disconnected",
                "message": "Credentials file or Sheet ID not found. Set GOOGLE_CREDENTIALS_FILE and GOOGLE_SHEET_ID environment variables."
            }
    except Exception as e:
        return {
            "service": "Google Sheets API",
            "status": "Error",
            "error": str(e)
        }


def append_content(topic: str, content: str, content_type: str, 
                  tone: str, quality_score: float) -> Dict:
    """Append generated content to sheet"""
    if not _google_sheets_client:
        connect_google_sheet()
    return _google_sheets_client.append_content(topic, content, content_type, tone, quality_score) if _google_sheets_client else {"error": "Client not initialized"}


def append_metrics(date: str, platform: str, engagement_rate: float,
                  reach: int, impressions: int, sentiment_score: float) -> Dict:
    """Append metrics to sheet"""
    if not _google_sheets_client:
        connect_google_sheet()
    return _google_sheets_client.append_metrics(date, platform, engagement_rate, reach, impressions, sentiment_score) if _google_sheets_client else {"error": "Client not initialized"}


def get_worksheet_data(worksheet_name: str) -> Dict:
    """Get worksheet data"""
    if not _google_sheets_client:
        connect_google_sheet()
    return _google_sheets_client.get_worksheet_data(worksheet_name) if _google_sheets_client else {"error": "Client not initialized"}


def get_client() -> Optional[GoogleSheetsClient]:
    """Get the global Google Sheets client instance"""
    if not _google_sheets_client:
        connect_google_sheet()
    return _google_sheets_client