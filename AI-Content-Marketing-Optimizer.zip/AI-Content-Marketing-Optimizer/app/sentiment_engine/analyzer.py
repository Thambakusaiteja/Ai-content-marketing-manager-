"""
Sentiment Analysis Module
Performs real sentiment analysis using VADER sentiment analyzer
"""

from nltk.sentiment import SentimentIntensityAnalyzer
import nltk
import re
from typing import Dict, List, Tuple

# Download required VADER lexicon
try:
    nltk.data.find('sentiment/vader_lexicon')
except LookupError:
    nltk.download('vader_lexicon')

# Initialize VADER sentiment analyzer
sia = SentimentIntensityAnalyzer()


def analyze_sentiment(text: str) -> Dict:
    """
    Performs real sentiment analysis on text using VADER.
    
    Args:
        text (str): Text to analyze
        
    Returns:
        dict: Sentiment analysis results including:
            - sentiment: Overall sentiment (Positive, Neutral, Negative)
            - confidence: Confidence score (0-1)
            - scores: Detailed compound, pos, neu, neg scores
            - intensity: Sentiment intensity (Very Strong, Strong, Moderate, Weak)
    """
    if not text or not isinstance(text, str):
        return {
            "text": text,
            "sentiment": "Neutral",
            "confidence": 0.0,
            "scores": {"compound": 0.0, "pos": 0.0, "neu": 1.0, "neg": 0.0},
            "intensity": "None",
            "error": "Invalid input text"
        }
    
    # Get VADER sentiment scores
    scores = sia.polarity_scores(text)
    
    # Determine sentiment based on compound score
    compound = scores['compound']
    
    if compound >= 0.05:
        sentiment = "Positive"
    elif compound <= -0.05:
        sentiment = "Negative"
    else:
        sentiment = "Neutral"
    
    # Calculate confidence based on the strongest score
    confidence = max(scores['pos'], scores['neu'], scores['neg'])
    
    # Determine intensity
    intensity = get_sentiment_intensity(compound)
    
    return {
        "text": text,
        "sentiment": sentiment,
        "confidence": round(confidence, 3),
        "scores": {
            "compound": round(compound, 3),
            "pos": round(scores['pos'], 3),
            "neu": round(scores['neu'], 3),
            "neg": round(scores['neg'], 3)
        },
        "intensity": intensity
    }


def analyze_batch_sentiment(texts: List[str]) -> List[Dict]:
    """
    Analyze sentiment for multiple texts.
    
    Args:
        texts (List[str]): List of texts to analyze
        
    Returns:
        List[Dict]: List of sentiment analysis results
    """
    return [analyze_sentiment(text) for text in texts]


def get_sentiment_intensity(compound_score: float) -> str:
    """
    Determine the intensity of sentiment based on compound score.
    
    Args:
        compound_score (float): VADER compound score
        
    Returns:
        str: Sentiment intensity
    """
    abs_score = abs(compound_score)
    
    if abs_score >= 0.75:
        return "Very Strong"
    elif abs_score >= 0.5:
        return "Strong"
    elif abs_score >= 0.25:
        return "Moderate"
    elif abs_score > 0.0:
        return "Weak"
    else:
        return "Neutral"


def predict_engagement_potential(sentiment_result: Dict) -> Dict:
    """
    Predict engagement potential based on sentiment analysis.
    
    Args:
        sentiment_result (Dict): Result from analyze_sentiment()
        
    Returns:
        Dict: Engagement predictions
    """
    sentiment = sentiment_result['sentiment']
    intensity = sentiment_result['intensity']
    confidence = sentiment_result['confidence']
    
    # Calculate engagement score (0-100)
    if sentiment == "Positive":
        base_score = 75 + (confidence * 25)
    elif sentiment == "Negative":
        base_score = 40 + (confidence * 20)
    else:  # Neutral
        base_score = 50 + (confidence * 10)
    
    engagement_score = min(100, max(0, base_score))
    
    # Determine engagement level
    if engagement_score >= 80:
        engagement_level = "Very High"
        recommendation = "Excellent engagement potential. Ready to publish."
    elif engagement_score >= 65:
        engagement_level = "High"
        recommendation = "Good engagement potential. Minor tweaks recommended."
    elif engagement_score >= 50:
        engagement_level = "Medium"
        recommendation = "Moderate engagement potential. Consider refinement."
    else:
        engagement_level = "Low"
        recommendation = "Consider revising for better engagement."
    
    return {
        "engagement_score": round(engagement_score, 1),
        "engagement_level": engagement_level,
        "recommendation": recommendation,
        "confidence": round(confidence, 3)
    }


def extract_emotions(text: str) -> Dict:
    """
    Extract emotional indicators from text.
    
    Args:
        text (str): Text to analyze
        
    Returns:
        Dict: Detected emotions and their strength
    """
    emotion_indicators = {
        "excitement": ["amazing", "awesome", "fantastic", "incredible", "wonderful", "love", "brilliant"],
        "concern": ["worried", "anxious", "concerned", "afraid", "scared", "nervous"],
        "anger": ["angry", "furious", "mad", "hate", "despise", "outraged"],
        "joy": ["happy", "joy", "delighted", "thrilled", "pleased", "satisfied"],
        "sadness": ["sad", "unhappy", "depressed", "disappointed", "sorry", "grief"],
        "trust": ["trusted", "reliable", "confident", "secure", "safe", "assured"]
    }
    
    text_lower = text.lower()
    detected_emotions = {}
    
    for emotion, keywords in emotion_indicators.items():
        matches = sum(1 for keyword in keywords if keyword in text_lower)
        if matches > 0:
            detected_emotions[emotion] = matches
    
    return detected_emotions


def compare_sentiments(text1: str, text2: str) -> Dict:
    """
    Compare sentiment between two texts.
    
    Args:
        text1 (str): First text
        text2 (str): Second text
        
    Returns:
        Dict: Comparison results
    """
    sentiment1 = analyze_sentiment(text1)
    sentiment2 = analyze_sentiment(text2)
    
    compound_diff = sentiment2['scores']['compound'] - sentiment1['scores']['compound']
    
    if abs(compound_diff) < 0.1:
        comparison = "Similar sentiment"
    elif compound_diff > 0:
        comparison = f"Text 2 is more positive (difference: {round(compound_diff, 3)})"
    else:
        comparison = f"Text 1 is more positive (difference: {round(abs(compound_diff), 3)})"
    
    return {
        "text1_sentiment": sentiment1,
        "text2_sentiment": sentiment2,
        "comparison": comparison,
        "compound_difference": round(compound_diff, 3)
    }
