"""
Sentiment Analysis Engine Package
Real sentiment analysis using VADER and NLTK
"""

from app.sentiment_engine.analyzer import (
    analyze_sentiment,
    analyze_batch_sentiment,
    predict_engagement_potential,
    extract_emotions,
    compare_sentiments,
    get_sentiment_intensity
)

__all__ = [
    "analyze_sentiment",
    "analyze_batch_sentiment",
    "predict_engagement_potential",
    "extract_emotions",
    "compare_sentiments",
    "get_sentiment_intensity"
]
