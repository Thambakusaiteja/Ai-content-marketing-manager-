# 🚀 AI Content Marketing Optimizer

An intelligent, AI-powered platform designed to help marketers create, optimize, and analyze content across multiple channels with ease. Leveraging advanced NLP and machine learning, this tool streamlines your content workflow from ideation to performance tracking.

## ✨ Features

### 📝 **Content Generation**
- AI-powered content creation for multiple formats (blog posts, social media, emails, video scripts)
- Customizable tone, length, and audience targeting
- SEO optimization built-in
- Keyword suggestion and integration
- Call-to-action generation

### 📊 **Performance Analytics**
- Real-time engagement tracking across platforms
- Comprehensive metrics dashboard
- Performance trends and insights
- Platform-specific analytics (Twitter, YouTube, Blog, Email)
- Conversion tracking

### 💭 **Sentiment Analysis**
- Automated content sentiment detection
- Emotion scoring
- Audience sentiment feedback analysis
- Engagement potential predictions
- Topic extraction and analysis

### 🔗 **API Integrations**
- **Google Sheets**: Easy data import/export and content calendar management
- **Twitter API**: Direct social media integration and performance tracking
- **YouTube API**: Video content optimization and analytics

### 📈 **Metrics Hub**
- Real-time performance tracking
- Customizable alerts for low engagement
- Trend analysis
- Comparative analytics

## 🎯 Project Structure

```
AI-Content-Marketing-Optimizer/
├── app/
│   ├── __init__.py
│   ├── api_integrations/
│   │   ├── google_sheets.py      # Google Sheets integration
│   │   ├── twitter_api.py        # Twitter API integration
│   │   └── youtube_api.py        # YouTube API integration
│   ├── content_engine/
│   │   ├── __init__.py
│   │   ├── generator.py          # AI content generation
│   │   └── optimizer.py          # Content optimization
│   ├── metrics_hub/
│   │   ├── alerts.py             # Alert system
│   │   └── tracker.py            # Metrics tracking
│   └── sentiment_engine/
│       ├── __init__.py
│       └── analyzer.py           # Sentiment analysis
├── config/
│   └── settings.yaml             # Configuration settings
├── data/
│   └── mock_engagement.csv       # Sample data
├── notebooks/                    # Jupyter notebooks for analysis
├── app_ui.py                     # Streamlit web interface
├── run.py                        # Main application entry point
├── requirements.txt              # Project dependencies
└── README.md                     # This file
```

## 🛠️ Installation

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

### Setup Instructions

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/AI-Content-Marketing-Optimizer.git
   cd AI-Content-Marketing-Optimizer
   ```

2. **Create a virtual environment** (recommended)
   ```bash
   python -m venv venv
   # On Windows
   venv\Scripts\activate
   # On macOS/Linux
   source venv/bin/activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Configure API keys**
   - Edit `config/settings.yaml` with your API keys:
     - Google Sheets API key
     - Twitter API credentials
     - YouTube API key

5. **Run the application**
   ```bash
   streamlit run app_ui.py
   ```

## 📋 Requirements

Core dependencies are listed in `requirements.txt`:

```
streamlit>=1.28.0
pandas>=2.0.0
plotly>=5.17.0
pyyaml>=6.0
google-auth>=2.25.0
tweepy>=4.14.0
google-api-python-client>=2.100.0
textblob>=0.17.1
nltk>=3.8.1
python-dotenv>=1.0.0
```

Install all requirements with:
```bash
pip install -r requirements.txt
```

## 🚀 Quick Start

### Using the Web Interface

1. **Start the Streamlit app**
   ```bash
   streamlit run app_ui.py
   ```

2. **Navigate to Dashboard**
   - View overall metrics and performance trends
   - Monitor engagement rates and campaign status

3. **Generate Content**
   - Select content type and target audience
   - Customize tone and length
   - Generate AI-optimized content
   - Copy, edit, or publish directly

4. **Analyze Performance**
   - View platform-specific analytics
   - Track engagement metrics
   - Compare content performance

5. **Sentiment Analysis**
   - Paste content to analyze
   - Get sentiment scores and insights
   - Identify engagement potential

### Using Python API

```python
from app.content_engine import generator, optimizer
from app.sentiment_engine import analyzer
from app.metrics_hub import tracker

# Generate content
content = generator.generate_content(
    topic="AI Marketing Trends",
    audience="Marketing Managers",
    tone="Professional",
    length=500
)

# Optimize content
optimized = optimizer.optimize_for_seo(content)

# Analyze sentiment
sentiment = analyzer.analyze(optimized)

# Track metrics
metrics = tracker.get_metrics(platform="Twitter")
```

## 🔧 Configuration

### Settings File (`config/settings.yaml`)

```yaml
# API Configuration
api:
  google_sheets:
    api_key: "your-api-key"
    sheet_id: "your-sheet-id"
  
  twitter:
    api_key: "your-api-key"
    api_secret: "your-api-secret"
    access_token: "your-access-token"
    access_secret: "your-access-secret"
  
  youtube:
    api_key: "your-api-key"

# Content Settings
content:
  default_tone: "Professional"
  default_length: 500
  seo_enabled: true

# Alert Settings
alerts:
  low_engagement_threshold: 3.0
  email_alerts: true
  daily_digest: true
```

## 📊 API Reference

### Content Generator
- `generate_content()` - Generate AI content
- `get_suggestions()` - Get content suggestions
- `validate_content()` - Validate content quality

### Optimizer
- `optimize_for_seo()` - SEO optimization
- `optimize_for_platform()` - Platform-specific optimization
- `improve_readability()` - Enhance readability

### Sentiment Analyzer
- `analyze()` - Analyze content sentiment
- `get_emotion_score()` - Get emotion scores
- `predict_engagement()` - Predict engagement potential

### Metrics Tracker
- `get_metrics()` - Get performance metrics
- `get_trends()` - Get trend analysis
- `compare_content()` - Compare content performance

## 📈 Usage Examples

### Example 1: Generate and Optimize Blog Post

```python
from app.content_engine import generator, optimizer

# Generate content
blog_post = generator.generate_content(
    topic="Machine Learning Applications",
    audience="Tech Professionals",
    tone="Educational",
    length=1500
)

# Optimize for SEO
optimized_post = optimizer.optimize_for_seo(blog_post)

# Optimize for readability
final_post = optimizer.improve_readability(optimized_post)

print(final_post)
```

### Example 2: Analyze Sentiment and Get Insights

```python
from app.sentiment_engine import analyzer

# Analyze content
content = "Our new product is revolutionizing the industry!"
sentiment_result = analyzer.analyze(content)

# Get detailed insights
emotion_score = analyzer.get_emotion_score(content)
engagement_potential = analyzer.predict_engagement(content)

print(f"Sentiment: {sentiment_result}")
print(f"Emotion Score: {emotion_score}")
print(f"Engagement Potential: {engagement_potential}")
```

### Example 3: Track Performance Metrics

```python
from app.metrics_hub import tracker

# Get metrics for a specific platform
twitter_metrics = tracker.get_metrics(platform="Twitter", days=30)

# Get trends
trends = tracker.get_trends(content_type="Blog Posts")

# Compare content performance
comparison = tracker.compare_content(content_ids=["id1", "id2", "id3"])
```

## 🎨 Dashboard Pages

### 1. Dashboard
- KPI cards (Total Content, Engagement Rate, Sentiment Score, Active Campaigns)
- Engagement trend chart
- Content type distribution
- Recent content list

### 2. Content Generator
- Topic and keyword input
- Audience selection
- Tone customization
- Content length slider
- SEO and CTA options
- Copy, edit, and publish buttons

### 3. Performance Analytics
- Platform-specific metrics
- Engagement and reach analysis
- Detailed metrics table
- Time period filtering

### 4. Sentiment Analysis
- Content paste area
- Sentiment breakdown (Positive/Neutral/Negative)
- Emotion scoring
- Engagement potential prediction
- Key insights

### 5. Settings
- API configuration
- Content preferences
- Notification settings
- Save/Reset options

## 🤝 Contributing

We welcome contributions! Here's how to get started:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Troubleshooting

### Import Errors
If you encounter import errors, ensure all dependencies are installed:
```bash
pip install -r requirements.txt
```

### API Key Issues
- Verify API keys in `config/settings.yaml`
- Check API key permissions
- Ensure keys haven't expired

### Streamlit Issues
- Clear Streamlit cache: `streamlit cache clear`
- Restart the app: `streamlit run app_ui.py --logger.level=debug`

## 📞 Support

For issues, questions, or suggestions:
- Open an issue on GitHub
- Check existing issues for solutions
- Join our community discussions

## 🗺️ Roadmap

- [ ] Advanced AI model integration
- [ ] Multi-language support
- [ ] Mobile app
- [ ] Real-time collaboration
- [ ] Advanced scheduling
- [ ] A/B testing framework
- [ ] Content calendar integration
- [ ] Competitor analysis

## 👥 Team

**AI Content Marketing Team**
- Version: 1.0.0
- Last Updated: December 2025

## 📚 Additional Resources

- [Streamlit Documentation](https://docs.streamlit.io/)
- [Plotly Documentation](https://plotly.com/python/)
- [Google Sheets API](https://developers.google.com/sheets/api)
- [Twitter API Documentation](https://developer.twitter.com/en/docs)
- [YouTube API](https://developers.google.com/youtube/v3)

---

**Made with ❤️ by the AI Content Marketing Team**
