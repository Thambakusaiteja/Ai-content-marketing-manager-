"""
Sentiment Analysis Demo and Testing Script
Demonstrates all features of the real VADER-based sentiment analyzer
"""

from app.sentiment_engine.analyzer import (
    analyze_sentiment,
    analyze_batch_sentiment,
    predict_engagement_potential,
    extract_emotions,
    compare_sentiments,
    get_sentiment_intensity
)


def demo_basic_sentiment_analysis():
    """Demo: Basic sentiment analysis"""
    print("\n" + "="*60)
    print("DEMO 1: Basic Sentiment Analysis")
    print("="*60)
    
    test_texts = [
        "I absolutely love this product! It's amazing and changed my life!",
        "This is okay, nothing special really.",
        "This is the worst experience I've ever had. Totally disappointed.",
        "Great job on the presentation! Very impressive work."
    ]
    
    for text in test_texts:
        result = analyze_sentiment(text)
        print(f"\nText: {text}")
        print(f"Sentiment: {result['sentiment']}")
        print(f"Confidence: {result['confidence']}")
        print(f"Intensity: {result['intensity']}")
        print(f"Scores - Pos: {result['scores']['pos']}, Neu: {result['scores']['neu']}, Neg: {result['scores']['neg']}, Compound: {result['scores']['compound']}")


def demo_batch_analysis():
    """Demo: Batch sentiment analysis"""
    print("\n" + "="*60)
    print("DEMO 2: Batch Sentiment Analysis")
    print("="*60)
    
    texts = [
        "Fantastic product with excellent customer service!",
        "Average quality, could be better.",
        "Horrible experience, won't buy again.",
        "Perfectly fine, does what it's supposed to do."
    ]
    
    results = analyze_batch_sentiment(texts)
    
    for i, result in enumerate(results, 1):
        print(f"\n{i}. {result['text'][:50]}...")
        print(f"   Sentiment: {result['sentiment']} (Confidence: {result['confidence']})")


def demo_engagement_prediction():
    """Demo: Predict engagement potential"""
    print("\n" + "="*60)
    print("DEMO 3: Engagement Potential Prediction")
    print("="*60)
    
    test_texts = [
        "🚀 Revolutionary AI technology that will transform the industry! Excited to share this breakthrough!",
        "Here are some tips for marketing.",
        "This is disappointing and needs improvement.",
    ]
    
    for text in test_texts:
        sentiment = analyze_sentiment(text)
        engagement = predict_engagement_potential(sentiment)
        
        print(f"\nText: {text}")
        print(f"Sentiment: {sentiment['sentiment']}")
        print(f"Engagement Score: {engagement['engagement_score']}/100 ({engagement['engagement_level']})")
        print(f"Recommendation: {engagement['recommendation']}")


def demo_emotion_extraction():
    """Demo: Extract emotions from text"""
    print("\n" + "="*60)
    print("DEMO 4: Emotion Extraction")
    print("="*60)
    
    test_texts = [
        "I'm so happy and excited about this amazing opportunity!",
        "I'm worried and concerned about the upcoming changes.",
        "This is fantastic and I love it! I'm thrilled!",
    ]
    
    for text in test_texts:
        emotions = extract_emotions(text)
        print(f"\nText: {text}")
        print(f"Detected Emotions: {emotions if emotions else 'None detected'}")


def demo_sentiment_comparison():
    """Demo: Compare sentiments between two texts"""
    print("\n" + "="*60)
    print("DEMO 5: Sentiment Comparison")
    print("="*60)
    
    text1 = "The product is good but has some issues."
    text2 = "This is an amazing product with incredible features!"
    
    comparison = compare_sentiments(text1, text2)
    
    print(f"\nText 1: {text1}")
    print(f"Sentiment: {comparison['text1_sentiment']['sentiment']}")
    print(f"Score: {comparison['text1_sentiment']['scores']['compound']}")
    
    print(f"\nText 2: {text2}")
    print(f"Sentiment: {comparison['text2_sentiment']['sentiment']}")
    print(f"Score: {comparison['text2_sentiment']['scores']['compound']}")
    
    print(f"\nComparison: {comparison['comparison']}")


def demo_sentiment_intensity():
    """Demo: Sentiment intensity levels"""
    print("\n" + "="*60)
    print("DEMO 6: Sentiment Intensity Levels")
    print("="*60)
    
    scores = [-0.95, -0.6, -0.3, -0.1, 0.0, 0.1, 0.3, 0.6, 0.95]
    
    print("\nCompound Score -> Intensity Mapping:")
    for score in scores:
        intensity = get_sentiment_intensity(score)
        print(f"Score: {score:6.2f} -> Intensity: {intensity}")


def run_all_demos():
    """Run all demonstration functions"""
    print("\n" + "#"*60)
    print("# AI CONTENT MARKETING OPTIMIZER - SENTIMENT ANALYSIS DEMO")
    print("#"*60)
    
    demo_basic_sentiment_analysis()
    demo_batch_analysis()
    demo_engagement_prediction()
    demo_emotion_extraction()
    demo_sentiment_comparison()
    demo_sentiment_intensity()
    
    print("\n" + "#"*60)
    print("# DEMO COMPLETE")
    print("#"*60 + "\n")


if __name__ == "__main__":
    run_all_demos()
