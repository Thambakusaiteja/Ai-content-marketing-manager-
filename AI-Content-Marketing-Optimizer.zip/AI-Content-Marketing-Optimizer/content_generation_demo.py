"""
Content Generation & Optimization Demo
Demonstrates AI-powered content generation and optimization features
"""

from app.content_engine.generator import (
    generate_content,
    generate_content_ideas,
    batch_generate_content
)

from app.content_engine.optimizer import (
    optimize_content,
    optimize_for_seo,
    optimize_for_engagement,
    optimize_for_readability
)


def demo_basic_content_generation():
    """Demo: Basic AI content generation"""
    print("\n" + "="*70)
    print("DEMO 1: Basic AI Content Generation")
    print("="*70)
    
    topics = [
        "Artificial Intelligence in Marketing",
        "Digital Transformation Strategy",
        "Social Media Engagement Tips"
    ]
    
    for topic in topics:
        print(f"\n📝 Topic: {topic}")
        print("-" * 70)
        
        result = generate_content(
            topic=topic,
            content_type="blog_post",
            audience="Marketing Managers",
            tone="Professional",
            length=300
        )
        
        print(f"Generated Content:\n{result['draft'][:300]}...")
        print(f"\nMetadata:")
        print(f"  - Content Type: {result['content_type']}")
        print(f"  - Audience: {result['audience']}")
        print(f"  - Tone: {result['tone']}")
        print(f"  - Model: {result['metadata']['model']}")
        print(f"  - Quality Score: {result['variations'][0]['quality_score']:.2f}")


def demo_content_types():
    """Demo: Different content types"""
    print("\n" + "="*70)
    print("DEMO 2: Various Content Types")
    print("="*70)
    
    content_types = [
        ("blog_post", 300),
        ("social_media", 150),
        ("email_newsletter", 250),
        ("video_script", 350)
    ]
    
    topic = "AI Content Marketing"
    
    for content_type, length in content_types:
        print(f"\n📄 Type: {content_type.replace('_', ' ').title()}")
        print("-" * 70)
        
        result = generate_content(
            topic=topic,
            content_type=content_type,
            tone="Inspirational",
            length=length
        )
        
        preview = result['draft'][:200] if len(result['draft']) > 200 else result['draft']
        print(f"Preview: {preview}...")
        print(f"Word Count: {len(result['draft'].split())}")


def demo_tone_variations():
    """Demo: Different tones for same topic"""
    print("\n" + "="*70)
    print("DEMO 3: Tone Variations")
    print("="*70)
    
    tones = ["Professional", "Casual", "Humorous", "Inspirational", "Educational"]
    topic = "Machine Learning"
    
    for tone in tones:
        print(f"\n🎭 Tone: {tone}")
        print("-" * 70)
        
        result = generate_content(
            topic=topic,
            content_type="social_media",
            tone=tone,
            length=200
        )
        
        preview = result['draft'][:150] if len(result['draft']) > 150 else result['draft']
        print(f"Content: {preview}...")


def demo_audience_targeting():
    """Demo: Audience targeting"""
    print("\n" + "="*70)
    print("DEMO 4: Audience-Specific Content")
    print("="*70)
    
    audiences = [
        "Tech Professionals",
        "Marketing Managers",
        "Business Owners",
        "Startups"
    ]
    
    topic = "Cloud Computing"
    
    for audience in audiences:
        print(f"\n👥 Audience: {audience}")
        print("-" * 70)
        
        result = generate_content(
            topic=topic,
            audience=audience,
            tone="Professional",
            length=250
        )
        
        preview = result['draft'][:180] if len(result['draft']) > 180 else result['draft']
        print(f"Content: {preview}...")


def demo_content_optimization():
    """Demo: Content optimization"""
    print("\n" + "="*70)
    print("DEMO 5: Content Optimization")
    print("="*70)
    
    # Generate initial content
    original = generate_content(
        topic="Digital Marketing",
        content_type="blog_post",
        tone="Professional",
        length=300
    )
    
    print("\n📝 ORIGINAL CONTENT:")
    print("-" * 70)
    print(original['draft'][:400])
    
    # Optimize the content
    optimized = optimize_content(original)
    
    print("\n\n✨ OPTIMIZED CONTENT:")
    print("-" * 70)
    print(optimized['optimized'][:400])
    
    print("\n\n📊 OPTIMIZATION IMPROVEMENTS:")
    print("-" * 70)
    for improvement in optimized['improvements']:
        print(f"  ✓ {improvement}")
    
    print(f"\nImprovement Score: {optimized['improvement_score']:.2f}/1.0")


def demo_content_ideas():
    """Demo: Generate multiple content ideas"""
    print("\n" + "="*70)
    print("DEMO 6: Content Ideas Generation")
    print("="*70)
    
    topic = "E-commerce Growth"
    
    print(f"\n🎯 Topic: {topic}")
    print("-" * 70)
    
    ideas = generate_content_ideas(topic, num_ideas=4)
    
    for i, idea in enumerate(ideas, 1):
        print(f"\n{i}. Content Type: {idea['type'].replace('_', ' ').title()}")
        print(f"   Preview: {idea['preview']}")


def demo_batch_generation():
    """Demo: Batch content generation"""
    print("\n" + "="*70)
    print("DEMO 7: Batch Content Generation")
    print("="*70)
    
    topics = [
        "AI Trends 2025",
        "Remote Work Best Practices",
        "Customer Retention Strategies"
    ]
    
    print(f"\n📦 Generating {len(topics)} content pieces...")
    print("-" * 70)
    
    results = batch_generate_content(
        topics=topics,
        content_type="blog_post",
        audience="Business Owners",
        tone="Professional"
    )
    
    for i, result in enumerate(results, 1):
        print(f"\n{i}. {result['topic']}")
        print(f"   Content: {result['draft'][:150]}...")
        print(f"   Quality Score: {result['variations'][0]['quality_score']:.2f}")


def demo_seo_optimization():
    """Demo: SEO-specific optimization"""
    print("\n" + "="*70)
    print("DEMO 8: SEO Optimization")
    print("="*70)
    
    topic = "Content Marketing Strategy"
    
    result = generate_content(
        topic=topic,
        content_type="blog_post",
        tone="Professional",
        length=400
    )
    
    print(f"\n📝 ORIGINAL CONTENT:")
    print("-" * 70)
    print(result['draft'][:300])
    
    seo_optimized = optimize_for_seo(result['draft'], topic=topic)
    
    print(f"\n\n🔍 SEO OPTIMIZED CONTENT:")
    print("-" * 70)
    print(seo_optimized[:300])


def demo_engagement_optimization():
    """Demo: Engagement optimization"""
    print("\n" + "="*70)
    print("DEMO 9: Engagement Optimization")
    print("="*70)
    
    result = generate_content(
        topic="Product Launch Strategy",
        content_type="blog_post",
        tone="Professional",
        length=300
    )
    
    print(f"\n📝 ORIGINAL CONTENT:")
    print("-" * 70)
    print(result['draft'][:300])
    
    engagement_optimized = optimize_for_engagement(result['draft'])
    
    print(f"\n\n⚡ ENGAGEMENT OPTIMIZED CONTENT:")
    print("-" * 70)
    print(engagement_optimized[:300])


def demo_readability_optimization():
    """Demo: Readability optimization"""
    print("\n" + "="*70)
    print("DEMO 10: Readability Optimization")
    print("="*70)
    
    result = generate_content(
        topic="Analytics and Insights",
        content_type="blog_post",
        tone="Educational",
        length=400
    )
    
    print(f"\n📝 ORIGINAL CONTENT:")
    print("-" * 70)
    print(result['draft'][:300])
    
    readability_optimized = optimize_for_readability(result['draft'])
    
    print(f"\n\n📖 READABILITY OPTIMIZED CONTENT:")
    print("-" * 70)
    print(readability_optimized[:300])


def run_all_demos():
    """Run all demonstration functions"""
    print("\n" + "#"*70)
    print("# AI CONTENT MARKETING OPTIMIZER - CONTENT GENERATION & OPTIMIZATION DEMO")
    print("#"*70)
    
    try:
        demo_basic_content_generation()
        demo_content_types()
        demo_tone_variations()
        demo_audience_targeting()
        demo_content_optimization()
        demo_content_ideas()
        demo_batch_generation()
        demo_seo_optimization()
        demo_engagement_optimization()
        demo_readability_optimization()
    except Exception as e:
        print(f"\n⚠️  Note: Some demos use the transformer model which requires transformers library.")
        print(f"   Error: {e}")
        print(f"\n   Install with: pip install transformers torch")
        print(f"\n   The code includes a fallback mechanism for template-based generation.")
    
    print("\n" + "#"*70)
    print("# DEMO COMPLETE")
    print("#"*70 + "\n")


if __name__ == "__main__":
    run_all_demos()
