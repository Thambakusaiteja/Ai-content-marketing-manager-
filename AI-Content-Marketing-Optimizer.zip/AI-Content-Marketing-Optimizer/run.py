from app.api_integrations.twitter_api import init_twitter_api
from app.api_integrations.youtube_api import init_youtube_api
from app.api_integrations.google_sheets import connect_google_sheet

from app.content_engine.generator import generate_content, generate_content_ideas
from app.content_engine.optimizer import optimize_content

from app.sentiment_engine.analyzer import (
    analyze_sentiment, 
    predict_engagement_potential,
    extract_emotions,
    get_sentiment_intensity
)

from app.metrics_hub.tracker import load_mock_metrics, calculate_metrics
from app.metrics_hub.alerts import engagement_alert


def main():
    print("\n" + "="*70)
    print("AI CONTENT MARKETING OPTIMIZER - COMPLETE PIPELINE DEMONSTRATION")
    print("="*70)

    # ========================================
    # 1. API INITIALIZATION
    # ========================================
    print("\n[1] 🔌 Initializing API Integrations...")
    print("-" * 70)
    print("   ✓", init_twitter_api()["status"])
    print("   ✓", init_youtube_api()["status"])
    print("   ✓", connect_google_sheet()["status"])

    # ========================================
    # 2. REAL AI CONTENT GENERATION
    # ========================================
    print("\n[2] 🤖 AI-Powered Content Generation Engine")
    print("-" * 70)
    
    topic = "AI Marketing Trends 2025"
    print(f"   Topic: {topic}\n")
    
    # Generate blog post
    print("   Generating blog post (Professional tone)...")
    blog_draft = generate_content(
        topic=topic,
        content_type="blog_post",
        audience="Marketing Managers",
        tone="Professional",
        length=300
    )
    print(f"   ✓ Generated {len(blog_draft['draft'].split())} words")
    print(f"   ✓ Content Type: {blog_draft['content_type']}")
    print(f"   ✓ Quality Score: {blog_draft['variations'][0]['quality_score']:.2f}")
    print(f"\n   Preview:\n   {blog_draft['draft'][:200]}...")
    
    # Generate social media content
    print("\n   Generating social media content (Casual tone)...")
    social_draft = generate_content(
        topic=topic,
        content_type="social_media",
        tone="Casual",
        length=150
    )
    print(f"   ✓ Generated social post")
    print(f"   ✓ Preview: {social_draft['draft'][:100]}...")
    
    # Use blog post for further pipeline
    draft = blog_draft

    # ========================================
    # 3. CONTENT OPTIMIZATION
    # ========================================
    print("\n[3] ✨ Content Optimization & Enhancement")
    print("-" * 70)
    print("   Applying SEO, readability, and engagement optimizations...")
    
    optimized = optimize_content(draft)
    print(f"   ✓ Applied {len(optimized['improvements'])} optimizations:")
    for improvement in optimized['improvements'][:3]:
        print(f"      - {improvement}")
    print(f"   ✓ Improvement Score: {optimized['improvement_score']:.2f}/1.0")
    print(f"\n   Optimized Preview:\n   {optimized['optimized'][:200]}...")
    
    # Use optimized content for sentiment analysis
    content_to_analyze = optimized.get("optimized", draft.get("draft", ""))

    # ========================================
    # 4. REAL SENTIMENT ANALYSIS
    # ========================================
    print("\n[4] 💭 Real Sentiment Analysis (VADER)")
    print("-" * 70)
    
    sentiment_result = analyze_sentiment(content_to_analyze)
    
    print(f"   Text Preview: {content_to_analyze[:70]}...")
    print(f"\n   Sentiment Analysis Results:")
    print(f"   ├─ Overall Sentiment: {sentiment_result['sentiment']} 📊")
    print(f"   ├─ Confidence: {sentiment_result['confidence']:.1%}")
    print(f"   ├─ Intensity: {sentiment_result['intensity']}")
    print(f"   └─ Scores:")
    print(f"      ├─ Compound: {sentiment_result['scores']['compound']:.3f}")
    print(f"      ├─ Positive: {sentiment_result['scores']['pos']:.1%}")
    print(f"      ├─ Neutral: {sentiment_result['scores']['neu']:.1%}")
    print(f"      └─ Negative: {sentiment_result['scores']['neg']:.1%}")
    
    # Predict engagement
    engagement = predict_engagement_potential(sentiment_result)
    print(f"\n   Engagement Prediction:")
    print(f"   ├─ Engagement Score: {engagement['engagement_score']:.1f}/100")
    print(f"   ├─ Level: {engagement['engagement_level']} 🎯")
    print(f"   └─ Recommendation: {engagement['recommendation']}")
    
    # Extract emotions
    emotions = extract_emotions(content_to_analyze)
    if emotions:
        print(f"\n   Detected Emotions:")
        for emotion, count in emotions.items():
            print(f"   ├─ {emotion.capitalize()}: {count}")

    # ========================================
    # 5. PERFORMANCE METRICS
    # ========================================
    print("\n[5] 📈 Performance Metrics & Analytics")
    print("-" * 70)
    df = load_mock_metrics()
    metrics = calculate_metrics(df)
    print(f"   {metrics}")

    # ========================================
    # 6. ALERT SYSTEM
    # ========================================
    print("\n[6] 🚨 Alert System & Recommendations")
    print("-" * 70)
    alert = engagement_alert(metrics)
    print(f"   {alert}")
    
    # ========================================
    # 7. CONTENT IDEAS GENERATION
    # ========================================
    print("\n[7] 💡 Generating Content Ideas")
    print("-" * 70)
    print(f"   Generating 3 content idea variations for '{topic}'...\n")
    
    try:
        ideas = generate_content_ideas(topic, num_ideas=3)
        for i, idea in enumerate(ideas, 1):
            print(f"   {i}. {idea['type'].replace('_', ' ').title()}")
            print(f"      Preview: {idea['preview']}")
    except Exception as e:
        print(f"   Note: Content ideas generation uses transformer model.")
        print(f"   Run 'pip install transformers torch' for full features.")
    
    # ========================================
    # SUMMARY
    # ========================================
    print("\n" + "="*70)
    print("✅ PIPELINE COMPLETE - ALL MODULES OPERATIONAL")
    print("="*70)
    print("\n📊 Summary:")
    print(f"   • Content Generated: ✓ (Quality: {draft['variations'][0]['quality_score']:.2f})")
    print(f"   • Content Optimized: ✓ (Score: {optimized['improvement_score']:.2f})")
    print(f"   • Sentiment Analyzed: ✓ ({sentiment_result['sentiment']})")
    print(f"   • Engagement Predicted: ✓ ({engagement['engagement_level']})")
    print(f"   • Metrics Tracked: ✓")
    print(f"   • Alerts Generated: ✓")
    print("\n" + "="*70 + "\n")

    
    # Predict engagement
    engagement = predict_engagement_potential(sentiment_result)
    print(f"\n   Engagement Prediction:")
    print(f"   ├─ Engagement Score: {engagement['engagement_score']}/100")
    print(f"   ├─ Level: {engagement['engagement_level']}")
    print(f"   └─ Recommendation: {engagement['recommendation']}")
    
    # Extract emotions
    emotions = extract_emotions(content_to_analyze)
    if emotions:
        print(f"\n   Detected Emotions:")
        for emotion, count in emotions.items():
            print(f"   ├─ {emotion.capitalize()}: {count}")

    # ========================================
    # 5. Metrics Hub (Milestone 3)
    # ========================================
    print("\n[5] Performance Metrics")
    print("-" * 60)
    df = load_mock_metrics()
    metrics = calculate_metrics(df)
    print(f"   {metrics}")

    # Alerts
    print("\n[6] Alert System")
    print("-" * 60)
    alert = engagement_alert(metrics)
    print(f"   {alert}")
    
    print("\n" + "="*60)
    print("PIPELINE COMPLETE")
    print("="*60 + "\n")


if __name__ == "__main__":
    main()
