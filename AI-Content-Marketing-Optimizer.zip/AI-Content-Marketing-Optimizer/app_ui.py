"""
AI Content Marketing Optimizer - Streamlit UI
"""

import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
import plotly.express as px
import plotly.graph_objects as go

# Page configuration
st.set_page_config(
    page_title="AI Content Marketing Optimizer",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
    <style>
    .main-header {
        font-size: 2.5rem;
        color: #1f77b4;
        font-weight: bold;
        margin-bottom: 1rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1.5rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
    }
    </style>
""", unsafe_allow_html=True)

# Sidebar navigation
st.sidebar.title("🎯 Navigation")
page = st.sidebar.radio(
    "Select a page:",
    ["Dashboard", "Content Generator", "Performance Analytics", "Sentiment Analysis", "Settings"]
)

# Header
st.markdown('<div class="main-header">AI Content Marketing Optimizer</div>', unsafe_allow_html=True)

# ============ DASHBOARD PAGE ============
if page == "Dashboard":
    st.header("📊 Dashboard")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(label="Total Content Created", value="156", delta="12 this week")
    
    with col2:
        st.metric(label="Avg Engagement Rate", value="4.2%", delta="0.3% ↑")
    
    with col3:
        st.metric(label="Sentiment Score", value="8.7/10", delta="0.5 ↑")
    
    with col4:
        st.metric(label="Active Campaigns", value="8", delta="2 new")
    
    st.divider()
    
    # Chart section
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📈 Content Performance Over Time")
        
        # Sample data
        dates = pd.date_range(start='2025-11-01', periods=30, freq='D')
        engagement = [3.2, 3.5, 4.1, 3.8, 4.5, 4.2, 4.8, 5.1, 4.9, 5.3,
                     5.5, 5.2, 5.8, 6.1, 5.9, 6.3, 6.5, 6.2, 6.8, 7.1,
                     6.9, 7.3, 7.5, 7.2, 7.8, 8.1, 7.9, 8.3, 8.5, 8.2]
        
        df_engagement = pd.DataFrame({
            'Date': dates,
            'Engagement Rate (%)': engagement
        })
        
        fig = px.line(df_engagement, x='Date', y='Engagement Rate (%)',
                     title='Engagement Trend', markers=True)
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.subheader("📋 Content Type Distribution")
        
        content_types = {
            'Blog Posts': 45,
            'Social Media': 38,
            'Videos': 32,
            'Infographics': 28,
            'Podcasts': 13
        }
        
        fig = px.pie(
            values=list(content_types.values()),
            names=list(content_types.keys()),
            title='Content Distribution'
        )
        st.plotly_chart(fig, use_container_width=True)
    
    st.divider()
    st.subheader("🎯 Recent Content")
    
    recent_content = pd.DataFrame({
        'Title': ['AI Trends 2025', 'Marketing Strategy Guide', 'Social Media Tips', 'Video Tutorial'],
        'Type': ['Blog', 'Blog', 'Social', 'Video'],
        'Date': ['2025-12-04', '2025-12-03', '2025-12-02', '2025-12-01'],
        'Engagement': ['4.8%', '5.2%', '3.9%', '6.1%'],
        'Status': ['Published', 'Published', 'Published', 'Published']
    })
    
    st.dataframe(recent_content, use_container_width=True, hide_index=True)

# ============ CONTENT GENERATOR PAGE ============
elif page == "Content Generator":
    st.header("✍️ Content Generator")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("Generate New Content")
        
        content_type = st.selectbox(
            "Content Type",
            ["Blog Post", "Social Media Caption", "Email Newsletter", "Video Script"]
        )
        
        topic = st.text_input("Topic or Keyword", placeholder="Enter your topic here...")
        
        audience = st.selectbox(
            "Target Audience",
            ["General", "Tech Professionals", "Marketing Managers", "Business Owners", "Startups"]
        )
        
        tone = st.selectbox(
            "Tone",
            ["Professional", "Casual", "Humorous", "Inspirational", "Educational"]
        )
        
        length = st.slider("Content Length", min_value=100, max_value=2000, value=500, step=100)
    
    with col2:
        st.subheader("Options")
        include_keywords = st.checkbox("Include Keywords", value=True)
        include_cta = st.checkbox("Include CTA", value=True)
        seo_optimized = st.checkbox("SEO Optimized", value=True)
    
    st.divider()
    
    if st.button("🚀 Generate Content", use_container_width=True):
        with st.spinner("Generating content..."):
            st.success("Content Generated Successfully!")
            
            st.subheader("Generated Content")
            sample_content = f"""
            # {topic}
            
            This is a sample {content_type.lower()} optimized for {audience} audience with a {tone.lower()} tone.
            
            The content has been generated with SEO optimization in mind and includes relevant keywords.
            
            ## Key Points
            - Point 1: Generated content based on your inputs
            - Point 2: Tailored for your target audience
            - Point 3: Optimized for engagement
            
            ## Call to Action
            Learn more about this topic by exploring our resources today!
            """
            
            st.markdown(sample_content)
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.button("📋 Copy Content")
            with col2:
                st.button("✏️ Edit")
            with col3:
                st.button("📤 Publish")

# ============ PERFORMANCE ANALYTICS PAGE ============
elif page == "Performance Analytics":
    st.header("📊 Performance Analytics")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        metric_type = st.selectbox("Metric", ["Engagement", "Reach", "Conversions"])
    
    with col2:
        date_range = st.selectbox("Time Period", ["Last 7 Days", "Last 30 Days", "Last 90 Days"])
    
    with col3:
        platform = st.selectbox("Platform", ["All", "Twitter", "YouTube", "Blog", "Email"])
    
    st.divider()
    
    # Performance by platform
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Performance by Platform")
        
        platform_data = pd.DataFrame({
            'Platform': ['Twitter', 'YouTube', 'Blog', 'Email', 'LinkedIn'],
            'Engagement': [4.2, 6.8, 5.3, 7.1, 4.5],
            'Reach': [15000, 45000, 28000, 12000, 18000]
        })
        
        fig = px.bar(platform_data, x='Platform', y='Engagement',
                    title='Engagement by Platform', color='Engagement')
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.subheader("Reach Analysis")
        
        fig = px.bar(platform_data, x='Platform', y='Reach',
                    title='Reach by Platform', color='Reach')
        st.plotly_chart(fig, use_container_width=True)
    
    st.divider()
    
    st.subheader("Detailed Metrics Table")
    
    metrics_df = pd.DataFrame({
        'Content': ['AI Trends', 'Marketing Guide', 'Social Tips', 'Video Tutorial'],
        'Impressions': [12500, 15200, 8900, 24500],
        'Clicks': [450, 680, 280, 1200],
        'Conversions': [45, 78, 28, 120],
        'Engagement Rate': ['3.6%', '4.5%', '3.1%', '4.9%']
    })
    
    st.dataframe(metrics_df, use_container_width=True, hide_index=True)

# ============ SENTIMENT ANALYSIS PAGE ============
elif page == "Sentiment Analysis":
    st.header("💭 Sentiment Analysis")
    
    st.subheader("Analyze Content Sentiment")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        content_to_analyze = st.text_area(
            "Enter content to analyze:",
            placeholder="Paste your content here...",
            height=200
        )
    
    with col2:
        analysis_type = st.radio(
            "Analysis Type",
            ["Overall", "By Topic", "By Audience"]
        )
    
    if st.button("🔍 Analyze Sentiment", use_container_width=True):
        if content_to_analyze:
            with st.spinner("Analyzing sentiment..."):
                st.success("Analysis Complete!")
                
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("Overall Sentiment", "Positive", "8.5/10")
                
                with col2:
                    st.metric("Emotion Score", "Enthusiastic", "92%")
                
                with col3:
                    st.metric("Engagement Potential", "High", "+15%")
                
                st.divider()
                
                # Sentiment breakdown
                sentiment_data = pd.DataFrame({
                    'Sentiment': ['Positive', 'Neutral', 'Negative'],
                    'Percentage': [78, 18, 4]
                })
                
                fig = px.pie(sentiment_data, values='Percentage', names='Sentiment',
                           color_discrete_map={'Positive': '#2ecc71', 'Neutral': '#95a5a6', 'Negative': '#e74c3c'})
                st.plotly_chart(fig, use_container_width=True)
                
                st.subheader("Key Insights")
                st.info("""
                - ✅ Strong positive sentiment detected
                - 🎯 High engagement potential with target audience
                - 💡 Key topics: Innovation, Growth, Success
                - 🔗 Recommended: Add more specific examples
                """)
        else:
            st.warning("Please enter content to analyze")

# ============ SETTINGS PAGE ============
elif page == "Settings":
    st.header("⚙️ Settings")
    
    with st.expander("API Configuration", expanded=True):
        st.subheader("API Keys")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.text_input("Google Sheets API Key", type="password", placeholder="Enter API key")
            st.text_input("Twitter API Key", type="password", placeholder="Enter API key")
        
        with col2:
            st.text_input("YouTube API Key", type="password", placeholder="Enter API key")
            st.text_input("Sentiment API Key", type="password", placeholder="Enter API key")
    
    with st.expander("Content Preferences"):
        st.subheader("Default Settings")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.selectbox("Default Tone", ["Professional", "Casual", "Humorous"])
            st.selectbox("Default Length", ["Short (100-300)", "Medium (300-800)", "Long (800+)"])
        
        with col2:
            st.multiselect("Preferred Platforms", 
                          ["Twitter", "LinkedIn", "Blog", "YouTube", "Email"],
                          default=["Twitter", "Blog"])
            st.number_input("Max Content per Day", min_value=1, max_value=50, value=10)
    
    with st.expander("Notifications"):
        st.subheader("Alert Settings")
        
        st.checkbox("Email alerts on low engagement", value=True)
        st.checkbox("Daily performance report", value=True)
        st.checkbox("Weekly content recommendations", value=True)
        st.checkbox("Alert on sentiment changes", value=True)
    
    st.divider()
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("💾 Save Settings", use_container_width=True):
            st.success("Settings saved successfully!")
    
    with col2:
        if st.button("🔄 Reset to Defaults", use_container_width=True):
            st.info("Settings reset to default values")

# Footer
st.divider()
st.markdown("""
    <div style='text-align: center; color: #999; font-size: 0.8rem;'>
    AI Content Marketing Optimizer v1.0.0 | © 2025 AI Content Marketing Team
    </div>
""", unsafe_allow_html=True)
